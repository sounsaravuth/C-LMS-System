USE LMS GO
-----Create Store Procedures---
--Insert Data--
create proc SP_BookTypeInsert
@bookidtype varchar(50),
@booktypename varchar(50),
@description varchar(50)
as
begin
INSERT INTO tblbooktype (bookidtype,booktypename,description) 
values(@bookidtype,@booktypename,@description);
end
---View Data---
create proc SP_BookTypeViewData
as
begin
SELECT * fROM tblbooktype;
end
--Update--
create proc SP_BookTypeUpdate
@bookidtype varchar(50),
@booktypename varchar(50),
@description varchar(50)
as
begin
Update tblbooktype set booktypename=@booktypename , description=@description where bookidtype=@bookidtype;
end
--Delete--
create proc SP_BookTypeDelete
@bookidtype varchar(50)
as
begin
DELETE FROM tblbooktype WHERE bookidtype=@bookidtype;
end