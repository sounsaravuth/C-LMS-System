use LMS GO
--Store Procedure--
--View Book Data--
create proc ViewBookData
as
begin
SELECT * FROM tblbook;
end
--Insert Book Data---
create proc InsertBookData
@bookid varchar(50),
@booktypeid varchar(50),
@qty int,
@bookname varchar(50),
@description varchar(50)
as
Begin
INSERT INTO tblbook (bookid,booktypeid,qty,bookname,description) values(@bookid,@booktypeid,@qty,@bookname,@description);
end
---Delete Book Data ---
create proc DeleteBookData
@bookid varchar(50)
as
Begin
DELETE FROM tblbook WHERE bookid=@bookid;
end
