USE LMS GO
--view ReturnBook--
create proc SP_ReturnViewBook
as
begin
SELECT * FROM tblreturn;
end
-----------------------
--Insert Book--
create proc SP_InsertReturnBook
@returnid varchar(50),
@studentid varchar(50),
@librarianid varchar(50),
@bookid varchar(50),
@phnumberreturn varchar(50),
@returndate date
as
begin
INSERT INTO tblreturn (returnid,studentid,librarianid,bookid,phnumberreturn,returndate)
values(@returnid,@studentid,@librarianid,@bookid,@phnumberreturn,@returndate);
end
-----------------------
--Delete---
create proc SP_ReturnBookDelete
@returnid varchar(50)
as
begin
DELETE FROM tblreturn WHERE returnid=@returnid;
end
------------------------
---Update------------
create proc SP_ReturnBookUpdate
@returnid varchar(50),
@studentid varchar(50),
@librarianid varchar(50),
@bookid varchar(50),
@phnumberreturn varchar(50),
@returndate date
as
begin
UPDATE tblreturn set studentid=@studentid,librarianid=@librarianid,bookid=@bookid,phnumberreturn=@phnumberreturn,returndate=@returndate where returnid=@returnid;
end
---------
