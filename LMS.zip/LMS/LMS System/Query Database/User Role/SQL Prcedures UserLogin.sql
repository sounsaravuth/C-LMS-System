use LMS GO
--Create UseLogin--
create proc SP_UserLoginViewData
as
begin
SELECT * FROM tbluserlogin;
end
-------------------
create proc SP_UserLoginCreate
@userid varchar(50),
@username varchar(50),
@password varchar(50),
@role varchar(50)
as
begin
INSERT INTO tbluserlogin (userid,username,password,role) values(@userid,@username,@password,@role);
end
create proc SP_UserLoginUpdate
@userid varchar(50),
@username varchar(50),
@password varchar(50),
@role varchar(50)
as
begin
UPDATE tbluserlogin set username=@username,password=@password,role=@role where userid=@userid;
end
create proc SP_UserLoginDelete
@userid varchar(50)
as
begin
DELETE FROM tbluserlogin where userid=@userid;
end