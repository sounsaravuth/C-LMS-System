USE LMS GO
create view V_FindStudenMale as
Select * from tblstudent where gender = 'Male';
create view V_FindStudenFemale as
Select * from tblstudent where gender = 'Female';
create view V_FindLibrarianMale as
select * from tbllibrarian where gender = 'Male';
create view V_FindLibrarianFemale as
select * from tbllibrarian where gender = 'Female';
create view V_CountBookInStock as
select count(bookid)as BookTotal from tblbook;
create view V_CountStudentInSchool as
select count(studentid)as TotalStudent from tblstudent;
create view V_FindInformationStudentInclass as
select * from tblstudent;