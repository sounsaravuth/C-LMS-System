USE LMS GO
--create Author---
create proc SP_AuthorViewData
@authorid varchar(50),
@authorname varchar(50),
@gender varchar(50),
@dob varchar(50),
@pob varchar(50),
@address varchar(50),
@tel varchar(50),
@email varchar(50)
as
begin
INSERT INTO tblauthor (authorid,authorname,gender,dob,pob,address,tel,email) values(@authorid,@authorname,@gender,@dob,@pob,@address,@tel,@email);
end
------------------
-----Update Author------
create proc SP_AuthorUpdateData
@authorid varchar(50),
@authorname varchar(50),
@gender varchar(50),
@dob varchar(50),
@pob varchar(50),
@address varchar(50),
@tel varchar(50),
@email varchar(50)
as
begin
Update tblauthor set authorid=@authorid,authorname=@authorname,gender=@gender,dob=@dob,pob=@pob,address=@address,tel=@tel,email=@email where authorid=@authorid;
end
------------------------
---Delete Author-------
create proc SP_AuthorDelete
@authorid varchar(50)
as
begin
DELETE FROM tblauthor where authorid=@authorid;
end
-----------------------