use LMS GO
--librarian ViewData--
create proc SP_librarianViewData
as
begin
SELECT * FROM tbllibrarian;
end
-----------------------------
----librarian InsertData-----
create proc SP_librarianInsertData
@librarianid varchar(50),
@librarianname varchar(50),
@gender varchar(50),
@dob varchar(50),
@pob varchar(50),
@address varchar(50),
@tel varchar(50),
@email varchar(50)
as
begin
INSERT INTO tbllibrarian(librarianid,librarianname,gender,dob,pob,address,tel,email)
values(@librarianid,@librarianname,@gender,@dob,@pob,@address,@tel,@email);
end
------------------------------
----Update librarian----------
create proc SP_librarianUpdateData
@librarianid varchar(50),
@librarianname varchar(50),
@gender varchar(50),
@dob varchar(50),
@pob varchar(50),
@address varchar(50),
@tel varchar(50),
@email varchar(50)
as
begin
Update tbllibrarian set librarianname=@librarianname,gender=@gender,dob=@dob,pob=@pob,address=@address,email=@email where librarianid=@librarianid;
end
----------------------------------
-------Delete librarian-----------
create proc SP_librarianDeleteData
@librarianid varchar(50)
as
begin
DELETE FROM tbllibrarian WHERE librarianid=@librarianid;
end
----------------------------------
