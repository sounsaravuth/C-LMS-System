USE LMS GO
--ViewData--
create proc SP_BookPublishViewData
as
begin
SELECT * FROM tblbookpublish;
end
--Insert---
create proc SP_BookPublishInsert
 @bookid  varchar(50),
@publisherid varchar(50),
@publishdate date,
@numberpublish varchar(50),
@notes varchar(50)
as
begin
INSERT INTO tblbookpublish (bookid,publisherid,publishdate,numberpublish,notes) 
values(@bookid,@publisherid,@publishdate,@numberpublish,@notes);
end
-------
create proc SP_BookPublishUpdate
 @bookid  varchar(50),
@publisherid varchar(50),
@publishdate date,
@numberpublish varchar(50),
@notes varchar(50)
as
begin
UPDATE tblbookpublish SET publisherid=@publisherid,publishdate=@publishdate,numberpublish=@numberpublish,notes=@notes where bookid=@bookid;
end
--------------
create proc SP_BookPublishDelete
@bookid varchar(50)
as
begin
DELETE FROM tblbookpublish WHERE bookid=@bookid;
end