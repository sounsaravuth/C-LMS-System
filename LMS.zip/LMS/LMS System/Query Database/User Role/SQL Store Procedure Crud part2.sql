use LMS Go
select * from tblbook;

create proc BookDelete
@bookid varchar(50)
as
begin
DELETE FROM tblbook where bookid=@bookid;
end

Create proc BookUpdate
@bookid varchar (50),
@booktypeid varchar(50),
@qty varchar(50),
@bookname varchar(50),
@description varchar(50)
as
begin
UPDATE tblbook SET booktypeid=@booktypeid,qty=@qty,bookname=@bookname,description=@description where bookid=@bookid;
end