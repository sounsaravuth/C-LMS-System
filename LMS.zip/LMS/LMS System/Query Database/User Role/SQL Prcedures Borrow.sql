USE LMS GO
--Create Store Procedures--
--ViewData--
create proc SP_BorrowViewData
as
begin
SELECT * FROM tblborrow;
end
--------------------------
--InsertData--
create proc SP_BorrowInsertData
@borrowid varchar(50),
@studentid varchar(50),
@librarianid varchar(50),
@bookid varchar(50),
@phnumberborrow varchar(50),
@borrowdate date,
@returndate date
as
begin
INSERT INTO tblborrow (borrowid,studentid,librarianid,bookid,phnumberborrow,borrowdate,returndate)
values(@borrowid,@studentid,@librarianid,@bookid,@phnumberborrow,@borrowdate,@returndate);
end
---------------------
--Delete Data--
create proc SP_BorrowDeleteData
@borrowid varchar(50)
as
begin
DELETE FROM tblborrow WHERE borrowid=@borrowid;
end
---------
---Update Data--------
create proc Sp_UpdateBorrowData
@borrowid varchar(50),
@studentid varchar(50),
@librarianid varchar(50),
@bookid varchar(50),
@phnumberborrow varchar(50),
@borrowdate date,
@returndate date
as
begin
UPDATE tblborrow set studentid=@studentid,librarianid=@librarianid,bookid=@bookid,phnumberborrow=@phnumberborrow,borrowdate=@borrowdate,returndate=@returndate where borrowid=@borrowid;
end
------------------------
