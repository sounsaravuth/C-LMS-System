use LMS go

--create store Procedures -- 
create proc InsertStudent
@studentid varchar(50),
@studentname varchar(50),
@gender varchar(50),
@dob date,
@pob varchar(50),
@address varchar(50),
@tel varchar(50),
@email varchar(50)
as
begin
INSERT INTO tblstudent (studentid,studentname,gender,dob,pob,address,tel,email)
values(@studentid,@studentname,@gender,@dob,@pob,@address,@tel,@email);
end
--view student Data---
create proc View_student
as
begin
Select * from tblstudent;
end
----Update Student----
create proc UpdateStudent
@studentid varchar(50),
@studentname varchar(50),
@gender varchar(50),
@dob date,
@pob varchar(50),
@address varchar(50),
@tel varchar(50),
@email varchar(50)
as
begin
Update tblstudent set studentname=@studentname, gender=@gender,dob=@dob,pob=@pob,address=@address,tel=@tel,email=@email where studentid=@studentid;
end
--Delete Student---
create proc DeleteStudent
@studentid varchar(50)
as
begin
DELETE FROM tblstudent WHERE studentid=@studentid;
end