create view bookauthors  AS
select tblauthor.authorid authorname,gender,dob,bookid,authordate from tblauthor inner join Bookauthor on tblauthor.authorid = Bookauthor.authorid;