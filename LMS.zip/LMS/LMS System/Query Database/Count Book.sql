use LMS GO
create view V_bookcount as
select COUNT (tblbook.bookid) as BookTotal from tblbook;