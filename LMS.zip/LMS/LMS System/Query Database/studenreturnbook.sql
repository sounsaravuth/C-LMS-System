
create view V_studentReturn as
select tblreturn.returnid,tblreturn.studentid,tblreturn.librarianid,tblreturn.phnumberreturn , tblreturn.returndate , tblstudent.studentname,tblstudent.gender,tblstudent.tel from tblreturn full join tblstudent on tblreturn.studentid = tblstudent.studentid;