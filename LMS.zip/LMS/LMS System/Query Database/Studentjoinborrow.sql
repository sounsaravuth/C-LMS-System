
create view V_studenBorrow as
select tblstudent.studentid,tblstudent.studentname,tblstudent.gender,tblstudent.tel,tblborrow.borrowid,tblborrow.bookid,tblborrow.phnumberborrow,tblborrow.borrowdate,tblborrow.returndate from tblstudent left join tblborrow on tblstudent.studentid = tblborrow.studentid ;