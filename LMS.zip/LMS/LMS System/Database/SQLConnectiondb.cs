﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Windows.Forms;
namespace LMS_System.Database
{
    class SQLConnectiondb
    {
        public static string sqlconnection = null;
        public static SqlConnection cnn;

     
        public void DatabaseConnection()
        {
            try
            {
                sqlconnection = "Data Source=DESKTOP-QSPL0PJ;Initial Catalog=LMS;integrated security=SSPI";
                cnn = new SqlConnection(sqlconnection);
                cnn.Open();
                // MessageBox.Show("Connection Successfully", "Successfully", MessageBoxButtons.OK, MessageBoxIcon.Information);
                cnn.Close();
            }
            catch (Exception e)
            {

                MessageBox.Show("Your Connection Can't Connect", e.Message,MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
           
        }
    }
}
