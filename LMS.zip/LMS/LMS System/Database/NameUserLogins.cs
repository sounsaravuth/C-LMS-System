﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LMS_System.Database
{
    class NameUserLogins
    {
        static string Uname;
        static string Role;
        static string Guest;
        static string Rolegust;

        public static string guest
        {
            get
            {
                return Guest;
            }
            set
            {
                Guest = value;
            }
        }


        public static string rolegust
        {
            get
            {
                return Rolegust;
            }
            set
            {
                Rolegust = value;
            }
        }
          public static string uname
         {
            get
            {
                return Uname;
            }
            set
            {
                Uname = value;
            }
         }

        public static string roles
        {
            get
            {
                return Role;
            }
            set
            {
                Role = value;
            }
        }

    }
}
