﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using LMS_System.Database;

namespace LMS_System.User
{
    public partial class frmBookReturnUserControl : Form
    {
        public frmBookReturnUserControl()
        {
            InitializeComponent();
        }

        private void frmBookReturnUserControl_Load(object sender, EventArgs e)
        {
            SQLConnectiondb connectiondb = new SQLConnectiondb();
            connectiondb.DatabaseConnection();
            ViewData();
            Getdatabookborrow();
            cbostuid.SelectedIndex = 0;
            FectchStudentData();
            cbolibid.SelectedIndex = 0;
            FectchLibranianData();
            cbobookid.SelectedIndex = 0;
            FectchBookData();
        }
        private void FectchStudentData()
        {
            try
            {
                SqlCommand command = new SqlCommand("Select * from tblstudent", SQLConnectiondb.cnn);
                SQLConnectiondb.cnn.Open();
                SqlDataReader reader = command.ExecuteReader();
                while (reader.Read())
                {
                    cbostuid.Items.Add(reader[0]);
                }
                SQLConnectiondb.cnn.Close();
            }
            catch (Exception e)
            {

                MessageBox.Show(e.Message);
            }
        }
        private void FectchLibranianData()
        {
            try
            {
                SqlCommand command = new SqlCommand("Select * from tbllibrarian", SQLConnectiondb.cnn);
                SQLConnectiondb.cnn.Open();
                SqlDataReader reader = command.ExecuteReader();
                while (reader.Read())
                {
                    cbolibid.Items.Add(reader[0]);
                }
                SQLConnectiondb.cnn.Close();
            }
            catch (Exception e)
            {

                MessageBox.Show(e.Message);
            }
        }
        private void FectchBookData()
        {
            try
            {
                SqlCommand command = new SqlCommand("Select * from tblbook", SQLConnectiondb.cnn);
                SQLConnectiondb.cnn.Open();
                SqlDataReader reader = command.ExecuteReader();
                while (reader.Read())
                {
                    cbobookid.Items.Add(reader[0]);
                }
                SQLConnectiondb.cnn.Close();
            }
            catch (Exception e)
            {

                MessageBox.Show(e.Message);
            }
        }
        private void ViewData()
        {
            try
            {
                SqlCommand command = new SqlCommand("exec SP_ReturnViewBook", SQLConnectiondb.cnn);
                SQLConnectiondb.cnn.Open();
                SqlDataAdapter adapter = new SqlDataAdapter(command);
                DataTable table = new DataTable();
                adapter.Fill(table);
                gunaDataGridView1.DataSource = table;
                SQLConnectiondb.cnn.Close();
            }
            catch (Exception e)
            {

                MessageBox.Show(e.Message);
            }
        }
        private void InsertData()
        {
            if(string.IsNullOrEmpty(txtreturnid.Text) && string.IsNullOrEmpty(cbostuid.Text))
            {
                MessageBox.Show("Please Complate Information Record Student !", "Information Alert", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }
            else
            {
                SqlCommand command = new SqlCommand("select * from tblreturn where returnid='"+txtreturnid.Text+"'", SQLConnectiondb.cnn);
                SqlDataAdapter adapter = new SqlDataAdapter(command);
                DataSet dataSet = new DataSet();
                adapter.Fill(dataSet);
                int i = dataSet.Tables[0].Rows.Count;
                if(i > 0)
                {
                    MessageBox.Show("Book Return Record exists", "Record Exists", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    dataSet.Clear();
                    return;
                }
            }
            try
            {
                SqlCommand command = new SqlCommand("exec SP_InsertReturnBook'"+txtreturnid.Text+"' , '"+cbostuid.Text+"' , '"+cbolibid.Text+"' , '"+cbobookid.Text+"','"+txtqty.Text+"','"+txtreturndate.Text+"'", SQLConnectiondb.cnn);
                SQLConnectiondb.cnn.Open();
                command.ExecuteNonQuery();
                SQLConnectiondb.cnn.Close();
                MessageBox.Show("Book Return Record Save Successfully", "Record Book Return", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch (Exception e)
            {

                MessageBox.Show(e.Message);
            }
        }

        private void DeleteData()
        {
            if (MessageBox.Show("Do You Want To Delete Record Book Return ?", "Question", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
            {
                try
                {
                    SqlCommand command = new SqlCommand("exec SP_ReturnBookDelete'"+txtreturnid.Text+"'", SQLConnectiondb.cnn);
                    SQLConnectiondb.cnn.Open();
                    command.ExecuteNonQuery();
                    SQLConnectiondb.cnn.Close();
                    MessageBox.Show("Book Return Record Delete Successfully", "Record Book Return Delete", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
                catch (Exception e)
                {

                    MessageBox.Show(e.Message);
                }
            }
        }
        //get data from book borrow
        private void Getdatabookborrow()
        {
            SqlCommand command = new SqlCommand("exec SP_BorrowViewData", SQLConnectiondb.cnn);
            SQLConnectiondb.cnn.Open();
            SqlDataAdapter adapter = new SqlDataAdapter(command);
            DataTable table = new DataTable();
            adapter.Fill(table);
            gunaDataGridView2.DataSource = table;
            SQLConnectiondb.cnn.Close();
        }
        private void button1_Click(object sender, EventArgs e)
        {
            InsertData();
            ViewData();
            ClearData();
        }
        private void ClearData()
        {
            txtqty.ResetText();
            cbobookid.SelectedIndex = 0;
            cbolibid.SelectedIndex = 0;
            cbostuid.SelectedIndex = 0;
            txtreturnid.Clear();
           
        }

        private void button2_Click(object sender, EventArgs e)
        {
            ClearData();
        }

        private void gunaDataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if(gunaDataGridView1.Rows[e.RowIndex].Cells[e.ColumnIndex].Value != null)
            {
                gunaDataGridView1.CurrentCell.Selected = true;
                txtreturnid.Text = gunaDataGridView1.Rows[e.RowIndex].Cells[0].Value.ToString();
                cbostuid.SelectedItem = gunaDataGridView1.Rows[e.RowIndex].Cells[1].Value.ToString();
                cbolibid.SelectedItem = gunaDataGridView1.Rows[e.RowIndex].Cells[2].Value.ToString();
                cbobookid.SelectedItem = gunaDataGridView1.Rows[e.RowIndex].Cells[3].Value.ToString();
                txtreturndate.Value = Convert.ToDateTime(gunaDataGridView1.Rows[e.RowIndex].Cells["returndate"].Value);
            }
        }
    }
}
