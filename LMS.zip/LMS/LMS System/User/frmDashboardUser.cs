﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using LMS_System.Database;
using LMS_System.Admin;

namespace LMS_System.User
{
    public partial class frmDashboardUser : Form
    {
        public frmDashboardUser()
        {
            InitializeComponent();
        }

        private void frmDashboardUser_Load(object sender, EventArgs e)
        {
            MainPanel.Controls.Clear();
            frmStudentUserControl frmStudentUserControl = new frmStudentUserControl();
            frmStudentUserControl.TopLevel = false;
            MainPanel.Controls.Add(frmStudentUserControl);
            frmStudentUserControl.Show();
            timer1.Enabled = true;
            lblusername.Text = NameUserLogins.guest;
            lbluserrole.Text = NameUserLogins.rolegust;
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
           
            lbldate.Text = DateTime.Now.ToLongDateString();
            lbltime.Text = DateTime.Now.ToLongTimeString();
         
        }

        private void button5_Click(object sender, EventArgs e)
        {
            frmlogin frmlogin = new frmlogin();
            frmlogin.Show();
            this.Hide();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            MainPanel.Controls.Clear();
            frmStudentUserControl frmStudentUserControl = new frmStudentUserControl();
            frmStudentUserControl.TopLevel = false;
            MainPanel.Controls.Add(frmStudentUserControl);
            frmStudentUserControl.Show();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            MainPanel.Controls.Clear();
            frmBookUserControls frmBookUserControls = new frmBookUserControls();
            frmBookUserControls.TopLevel = false;
            MainPanel.Controls.Add(frmBookUserControls);
            frmBookUserControls.Show();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            MainPanel.Controls.Clear();
            frmBookBorrowUserControl frmBookBorrowUserControl = new frmBookBorrowUserControl();
            frmBookBorrowUserControl.TopLevel = false;
            MainPanel.Controls.Add(frmBookBorrowUserControl);
            frmBookBorrowUserControl.Show();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            MainPanel.Controls.Clear();
            frmBookReturnUserControl frmBookReturnUserControl = new frmBookReturnUserControl();
            frmBookReturnUserControl.TopLevel = false;
            MainPanel.Controls.Add(frmBookReturnUserControl);
            frmBookReturnUserControl.Show();
        }
    }
}
