﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using LMS_System.Database;
using LMS_System.Admin.FormReport;

namespace LMS_System.User
{
    public partial class frmBookBorrowUserControl : Form
    {
        public frmBookBorrowUserControl()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void frmBookBorrowUserControl_Load(object sender, EventArgs e)
        {
            SQLConnectiondb connectiondb = new SQLConnectiondb();
            connectiondb.DatabaseConnection();
            ViewData();
            cbostuid.SelectedIndex = 0;
            FectchStudentData();
            cbolibid.SelectedIndex = 0;
            FectchLibranianData();
            cbobookid.SelectedIndex = 0;
            FectchBookData();
        }
        private void FectchStudentData()
        {
            try
            {
                SqlCommand command = new SqlCommand("Select * from tblstudent", SQLConnectiondb.cnn);
                SQLConnectiondb.cnn.Open();
                SqlDataReader reader = command.ExecuteReader();
                while (reader.Read())
                {
                    cbostuid.Items.Add(reader[0]);
                }
                SQLConnectiondb.cnn.Close();
            }
            catch (Exception e)
            {

                MessageBox.Show(e.Message);
            }
        }
        private void FectchLibranianData()
        {
            try
            {
                SqlCommand command = new SqlCommand("Select * from tbllibrarian", SQLConnectiondb.cnn);
                SQLConnectiondb.cnn.Open();
                SqlDataReader reader = command.ExecuteReader();
                while (reader.Read())
                {
                    cbolibid.Items.Add(reader[0]);
                }
                SQLConnectiondb.cnn.Close();
            }
            catch (Exception e)
            {

                MessageBox.Show(e.Message);
            }
        }
        private void FectchBookData()
        {
            try
            {
                SqlCommand command = new SqlCommand("Select * from tblbook", SQLConnectiondb.cnn);
                SQLConnectiondb.cnn.Open();
                SqlDataReader reader = command.ExecuteReader();
                while (reader.Read())
                {
                    cbobookid.Items.Add(reader[0]);
                }
                SQLConnectiondb.cnn.Close();
            }
            catch (Exception e)
            {

                MessageBox.Show(e.Message);
            }
        }
        private void ViewData()
        {
            try
            {
                SqlCommand command = new SqlCommand("exec SP_BorrowViewData", SQLConnectiondb.cnn);
                SQLConnectiondb.cnn.Open();
                SqlDataAdapter adapter = new SqlDataAdapter(command);
                DataTable table = new DataTable();
                adapter.Fill(table);
                gunaDataGridView1.DataSource = table;
                SQLConnectiondb.cnn.Close();
            }
            catch (Exception e)
            {

                MessageBox.Show(e.Message);
            }
        }
        private void InsertData()
        {
            if(string.IsNullOrEmpty(txtborrowid.Text) && string.IsNullOrEmpty(cbostuid.Text) && string.IsNullOrEmpty(cbolibid.Text) && string.IsNullOrEmpty(cbobookid.Text))
            {
                MessageBox.Show("Please Complate Information Book Borrow Record", "Complate Information", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }
            else
            {
                SqlCommand command = new SqlCommand("Select * from tblborrow where borrowid='"+txtborrowid.Text+"'", SQLConnectiondb.cnn);
                SqlDataAdapter adapter = new SqlDataAdapter(command);
                DataSet dataSet = new DataSet();
                adapter.Fill(dataSet);
                int i = dataSet.Tables[0].Rows.Count;
                if(i > 0)
                {
                    MessageBox.Show("Book Borrow Record Extist !", "Book Record Extist", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    dataSet.Clear();
                    return;
                }
            }
            try
            {
                SqlCommand command = new SqlCommand("exec SP_BorrowInsertData '" + txtborrowid.Text+"' ,'"+cbostuid.Text+"','"+cbolibid.Text+"','"+cbobookid.Text+"','"+txtqty.Text+"','"+txtborrowdate.Text+"','"+txtreturndate.Text+"'", SQLConnectiondb.cnn);
                SQLConnectiondb.cnn.Open();
                command.ExecuteNonQuery();
                MessageBox.Show(" Book Borrow Record Save Successfully", "Book Save", MessageBoxButtons.OK, MessageBoxIcon.Information);
                SQLConnectiondb.cnn.Close();
               

            }
            catch (Exception e)
            {

                MessageBox.Show(e.Message);
            }
        }
        private void UpdateData()
        {
            if (MessageBox.Show("Do You Want To Update Book Borrow Record", "Question", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
            {
                try
                {
                    SqlCommand command = new SqlCommand("exec Sp_UpdateBorrowData'" + txtborrowid.Text + "' ,'" + cbostuid.Text + "','" + cbolibid.Text + "','" + cbobookid.Text + "','" + txtqty.Text + "','" + txtborrowdate.Text + "','" + txtreturndate.Text + "'", SQLConnectiondb.cnn);
                    SQLConnectiondb.cnn.Open();
                    command.ExecuteNonQuery();
                    MessageBox.Show(" Book Borrow Record Update Successfully", "Book Borrow Update", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    SQLConnectiondb.cnn.Close();
                  
                }
                catch (Exception e)
                {

                    MessageBox.Show(e.Message);
                }
            }
        }
        private void DeleteData()
        {
            if (MessageBox.Show("Do You Want To Update Book Borrow Record", "Question", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
            {
                try
                {
                    SqlCommand command = new SqlCommand("exec SP_BorrowDeleteData'"+txtborrowid.Text+"'", SQLConnectiondb.cnn);
                    SQLConnectiondb.cnn.Open();
                    command.ExecuteNonQuery();
                    MessageBox.Show(" Book Borrow Record Delete Successfully", "Book Delete", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    SQLConnectiondb.cnn.Close();
                   
                }
                catch (Exception e)
                {

                    MessageBox.Show(e.Message);
                }
            }
        }
        private void ClearData()
        {
            txtborrowid.Clear();
            cbostuid.SelectedIndex = 0;
            cbolibid.SelectedIndex = 0;
            cbobookid.SelectedIndex = 0;
            txtqty.Clear();
        }
        private void SearchData()
        {
            try
            {
                SqlCommand command = new SqlCommand("Select * from tblborrow where borrowid like'%"+txtsearch.Text+"%'", SQLConnectiondb.cnn);
                SQLConnectiondb.cnn.Open();
                SqlDataAdapter adapter = new SqlDataAdapter(command);
                DataTable table = new DataTable();
                adapter.Fill(table);
                gunaDataGridView1.DataSource = table;
                SQLConnectiondb.cnn.Close();
            }
            catch (Exception e)
            {

                MessageBox.Show(e.Message);
            }
        }

        private void txtsearch_TextChanged(object sender, EventArgs e)
        {
            SearchData();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            InsertData();
            ViewData();
            ClearData();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            UpdateData();
            ViewData();
            ClearData();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            DeleteData();
            ViewData();
            ClearData();
        }

        private void gunaDataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            //click To Update
            if(gunaDataGridView1.Rows[e.RowIndex].Cells[e.ColumnIndex].Value != null)
            {
                gunaDataGridView1.CurrentCell.Selected = true;
                txtborrowid.Text = gunaDataGridView1.Rows[e.RowIndex].Cells[0].Value.ToString();
                cbostuid.Text = gunaDataGridView1.Rows[e.RowIndex].Cells[1].Value.ToString();
                cbolibid.Text = gunaDataGridView1.Rows[e.RowIndex].Cells[2].Value.ToString();
                cbobookid.Text = gunaDataGridView1.Rows[e.RowIndex].Cells[3].Value.ToString();
                txtqty.Text = gunaDataGridView1.Rows[e.RowIndex].Cells[4].Value.ToString();
                txtborrowdate.Value = Convert.ToDateTime(gunaDataGridView1.Rows[e.RowIndex].Cells["borrowdate"].Value);
                txtreturndate.Value = Convert.ToDateTime(gunaDataGridView1.Rows[e.RowIndex].Cells["returndate"].Value);
            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            frmbookBorrowRp frmbookBorrowRp = new frmbookBorrowRp();
            frmbookBorrowRp.Show();
            frmbookBorrowRp.Refresh();
        }
    }
}
