﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using LMS_System.Database;
using LMS_System.Admin.FormReport;
using System.Data.SqlClient;
namespace LMS_System.User
{
    public partial class frmStudentUserControl : Form
    {
        String Sex;
        public frmStudentUserControl()
        {
            InitializeComponent();
        }

        private void frmStudentUserControl_Load(object sender, EventArgs e)
        {
            SQLConnectiondb connectiondb = new SQLConnectiondb();
            connectiondb.DatabaseConnection();
            ViewData();
        }
        private void ViewData()
        {
            try
            {
                SqlCommand command = new SqlCommand("exec View_student", SQLConnectiondb.cnn);
                SQLConnectiondb.cnn.Open();
                SqlDataReader reader = command.ExecuteReader();
                bindingSource1.DataSource = reader;
                gunaDataGridView1.DataSource = bindingSource1;
                SQLConnectiondb.cnn.Close();
            }
            catch (Exception e)
            {

                MessageBox.Show(e.Message);
            }
        }
        private void SearchData()
        {
            try
            {
                SqlCommand command = new SqlCommand("Select * from tblstudent where studentname like'%"+txtsearch.Text+"%'", SQLConnectiondb.cnn);
                SQLConnectiondb.cnn.Open();
                SqlDataReader reader = command.ExecuteReader();
                bindingSource1.DataSource = reader;
                gunaDataGridView1.DataSource = bindingSource1;
                SQLConnectiondb.cnn.Close();
            }
            catch (Exception e)
            {

                MessageBox.Show(e.Message);
            }
        }

        private void InsertData()
        {
            if(string.IsNullOrEmpty(txtstudentid.Text) && string.IsNullOrEmpty(txtsudenname.Text))
            {
                MessageBox.Show("Please Complate Information Record Student !", "Information Alert", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }
            else
            {
                SqlCommand command = new SqlCommand("Select * from tblstudent where studentid='"+txtstudentid.Text+"'", SQLConnectiondb.cnn);
                SqlDataAdapter adapter = new SqlDataAdapter(command);
                DataSet dataSet = new DataSet();
                adapter.Fill(dataSet);
                int i = dataSet.Tables[0].Rows.Count;
                if (i > 0)
                {
                    MessageBox.Show("Record Student exists" , "Record Exists",MessageBoxButtons.OK,MessageBoxIcon.Warning);
                    dataSet.Clear();
                    return;
                }
            }
            try
            {
                SqlCommand command = new SqlCommand("exec InsertStudent '"+txtstudentid.Text+"' , '"+txtsudenname.Text+"' , '"+Sex+"' , '"+txtdate.Text+"' , '"+txtpob.Text+"','"+txtaddress.Text+"' ,'"+txttel.Text+"','"+txtemail.Text+"'", SQLConnectiondb.cnn);
                SQLConnectiondb.cnn.Open();
                command.ExecuteNonQuery();
                SQLConnectiondb.cnn.Close();
                MessageBox.Show("Record Student Save Successfully" , "Record Student Save",MessageBoxButtons.OK,MessageBoxIcon.Information);
            }
            catch (Exception e)
            {

                MessageBox.Show(e.Message);
            }
        }
        private void DeleteData()
        {
            if(MessageBox.Show("Do You Want To Delete Record Student ?" ,"Question",MessageBoxButtons.YesNo,MessageBoxIcon.Question)== DialogResult.Yes)
            {
                try
                {
                    SqlCommand command = new SqlCommand("exec DeleteStudent '"+txtstudentid.Text+"'", SQLConnectiondb.cnn);
                    SQLConnectiondb.cnn.Open();
                    command.ExecuteNonQuery();
                    SQLConnectiondb.cnn.Close();
                    MessageBox.Show("Record Student Delete Successfully" , "Record Student Delete",MessageBoxButtons.OK,MessageBoxIcon.Information);
                }
                catch (Exception e)
                {

                    MessageBox.Show(e.Message);
                }
            }
        }
        private void UpdateData()
        {
            if (MessageBox.Show("Do You Want To Update Record Student ?", "Question", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
            {
                try
                {
                    SqlCommand command = new SqlCommand("exec UpdateStudent '" + txtstudentid.Text + "' , '" + txtsudenname.Text + "' , '" + Sex + "' , '" + txtdate.Text + "' , '" + txtpob.Text + "','" + txtaddress.Text + "' ,'" + txttel.Text + "','" + txtemail.Text + "'", SQLConnectiondb.cnn);
                  
                    SQLConnectiondb.cnn.Open();
                    command.ExecuteNonQuery();
                    SQLConnectiondb.cnn.Close();
                    MessageBox.Show("Record Student Update Succesfully", "Student Update", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
                catch (Exception e)
                {

                    MessageBox.Show(e.Message);
                }
            }
        }
        private void ClearData()
        {
            txtstudentid.Clear();
            txtsudenname.Clear();
            checkBox1.Checked = false;
            checkBox2.Checked = false;
            txtpob.Clear();
            txtaddress.Clear();
            txttel.Clear();
            txtemail.Clear();
            
        }
        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {
            Sex = "Male";
        }

        private void checkBox2_CheckedChanged(object sender, EventArgs e)
        {
            Sex = "Female";
        }

        private void txtsearch_TextChanged(object sender, EventArgs e)
        {
            SearchData();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            InsertData();
            ViewData();
            ClearData();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            DeleteData();
            ViewData();
            ClearData();
        }

        private void gunaDataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (gunaDataGridView1.Rows[e.RowIndex].Cells[e.ColumnIndex].Value != null)
            {
                gunaDataGridView1.CurrentCell.Selected = true;
                txtstudentid.Text = gunaDataGridView1.Rows[e.RowIndex].Cells[0].Value.ToString();
                txtsudenname.Text = gunaDataGridView1.Rows[e.RowIndex].Cells[1].Value.ToString();
                if (gunaDataGridView1.SelectedRows[0].Cells[2].Value.Equals("Male"))
                {
                    checkBox1.Checked = true;
                }
                else
                {
                    checkBox1.Checked = false;
                }
                if (gunaDataGridView1.SelectedRows[0].Cells[3].Value.Equals("Female"))
                {
                    checkBox2.Checked = true;
                }
                else
                {
                    checkBox2.Checked = false;
                }
                txtdate.Value = Convert.ToDateTime(gunaDataGridView1.Rows[e.RowIndex].Cells["dob"].Value);
                txtpob.Text = gunaDataGridView1.Rows[e.RowIndex].Cells[4].Value.ToString();
                txtaddress.Text = gunaDataGridView1.Rows[e.RowIndex].Cells[5].Value.ToString();
                txttel.Text = gunaDataGridView1.Rows[e.RowIndex].Cells[6].Value.ToString();
                txtemail.Text = gunaDataGridView1.Rows[e.RowIndex].Cells[7].Value.ToString();


            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            UpdateData();
            ViewData();
            ClearData();
        }

        private void gunaDataGridView1_DataError(object sender, DataGridViewDataErrorEventArgs e)
        {
            if (e.Exception.Message == "DataGridView Validating")
            {
                object value = gunaDataGridView1.Rows[e.RowIndex].Cells[e.ColumnIndex].Value;
                if (!((DataGridViewComboBoxColumn)gunaDataGridView1.Columns[e.ColumnIndex]).Items.Contains(value))
                {
                    ((DataGridViewComboBoxColumn)gunaDataGridView1.Columns[e.ColumnIndex]).Items.Add(value);
                    e.ThrowException = false;
                }
            }
        }

        private void txtsudenname_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.Handled = !(char.IsLetter(e.KeyChar) || e.KeyChar == (char)Keys.Back || e.KeyChar == (char)Keys.Space || e.KeyChar == (char)Keys.Enter))
            {
                e.Handled = true;
                base.OnKeyPress(e);
                MessageBox.Show("allow Only Letter ", "Allow Only Letter", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }

        private void txtpob_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.Handled = !(char.IsLetter(e.KeyChar) || e.KeyChar == (char)Keys.Back || e.KeyChar == (char)Keys.Space || e.KeyChar == (char)Keys.Enter))
            {
                e.Handled = true;
                base.OnKeyPress(e);
                MessageBox.Show("allow Only Letter ", "Allow Only Letter", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }

        private void txtaddress_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.Handled = !(char.IsLetter(e.KeyChar) || e.KeyChar == (char)Keys.Back || e.KeyChar == (char)Keys.Space || e.KeyChar == (char)Keys.Enter))
            {
                e.Handled = true;
                base.OnKeyPress(e);
                MessageBox.Show("allow Only Letter ", "Allow Only Letter", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            frmstudentRP frmstudentRP = new frmstudentRP();
            frmstudentRP.Show();
            frmstudentRP.Refresh();
        }
    }
}
