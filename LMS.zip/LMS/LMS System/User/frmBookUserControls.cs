﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using LMS_System.Admin.FormReport;
using LMS_System.Database;


namespace LMS_System.User
{
    public partial class frmBookUserControls : Form
    {
        public frmBookUserControls()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void frmBookUserControls_Load(object sender, EventArgs e)
        {
            SQLConnectiondb connectiondb = new SQLConnectiondb();
            connectiondb.DatabaseConnection();
            ViewData();
            cbobookidtype.Items.Add("Select BookType ID");
            cbobookidtype.SelectedIndex = 0;
            FetchRecrodBookID();
        }
        private void ViewData()
        {
            try
            {
                SqlCommand command = new SqlCommand("exec ViewBookData", SQLConnectiondb.cnn);
                SQLConnectiondb.cnn.Open();
                SqlDataAdapter adapter = new SqlDataAdapter(command);
                DataTable table = new DataTable();
                adapter.Fill(table);
                gunaDataGridView1.DataSource = table;
                SQLConnectiondb.cnn.Close();
            }
            catch (Exception e)
            {

                MessageBox.Show(e.Message);
            }
        }
        private void SearchData()
        {
            try
            {
                SqlCommand command = new SqlCommand("select * from tblbook where bookname like'%"+txtsearch.Text+"%'", SQLConnectiondb.cnn);
                SQLConnectiondb.cnn.Open();
                SqlDataAdapter adapter = new SqlDataAdapter(command);
                DataTable table = new DataTable();
                adapter.Fill(table);
                gunaDataGridView1.DataSource = table;
                SQLConnectiondb.cnn.Close();
            }
            catch (Exception e)
            {

                MessageBox.Show(e.Message);
            }
        }
        private void FetchRecrodBookID()
        {
            try
            {
                SqlCommand command = new SqlCommand("select * from tblbooktype", SQLConnectiondb.cnn);
                SQLConnectiondb.cnn.Open();
                SqlDataReader reader = command.ExecuteReader();
                while (reader.Read())
                {
                    cbobookidtype.Items.Add(reader[0]);
                }
                SQLConnectiondb.cnn.Close();
            }
            catch (Exception e)
            {

                MessageBox.Show(e.Message);
            }
        }
        private void InsertData()
        {
            if(string.IsNullOrEmpty(txtbookid.Text) && string.IsNullOrEmpty(cbobookidtype.Text) && string.IsNullOrEmpty(txtqty.Value.ToString()))
            {
                MessageBox.Show("Please Complate Information Book Record" , "Complate Information" ,MessageBoxButtons.OK,MessageBoxIcon.Warning);
                return;
            }
            else
            {
                SqlCommand command = new SqlCommand("Select * from tblbook where bookid='" + txtbookid.Text + "'", SQLConnectiondb.cnn);
                SqlDataAdapter adapter = new SqlDataAdapter(command);
                DataSet dataSet = new DataSet();
                adapter.Fill(dataSet);
                int i = dataSet.Tables[0].Rows.Count;
                if (i > 0)
                {
                    MessageBox.Show("Book Record Extist !", "Book Record Extist", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    dataSet.Clear();
                    return;
                }
            }
            try
            {
                SqlCommand command = new SqlCommand("exec InsertBookData'"+txtbookid.Text+"' , '"+cbobookidtype.SelectedItem.ToString()+"','"+txtqty.Value.ToString()+"','"+txtbookname.Text+"' , '"+txtbookdeatil.Text+"'", SQLConnectiondb.cnn);
                SQLConnectiondb.cnn.Open();
                command.ExecuteNonQuery();
                SQLConnectiondb.cnn.Close();
                MessageBox.Show(" Book Record Save Successfully", "Book Save", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch (Exception e)
            {

                MessageBox.Show(e.Message);
            }
        }
        private void UpdateData()
        {
            if(MessageBox.Show("Do You Want To Update Book Record" , "Question" , MessageBoxButtons.YesNo ,MessageBoxIcon.Question) == DialogResult.Yes)
            {
                try
                {
                    SqlCommand command = new SqlCommand("exec BookUpdate'" + txtbookid.Text + "','" + cbobookidtype.SelectedItem.ToString() + "','" + txtqty.Value.ToString() + "','" + txtbookname.Text + "' , '" + txtbookdeatil.Text + "'", SQLConnectiondb.cnn);
                    SQLConnectiondb.cnn.Open();
                    command.ExecuteNonQuery();                  
                    MessageBox.Show(" Book Record Update Successfully", "Book Update", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    SQLConnectiondb.cnn.Close();
                }
                catch (Exception e)
                {

                    MessageBox.Show(e.Message);
                }
            }
        }
        private void DeleteData()
        {
            if (MessageBox.Show("Do You Want To Update Book Record", "Question", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
            {
                try
                {
                    SqlCommand command = new SqlCommand("exec deletebook'"+txtbookid.Text+"'", SQLConnectiondb.cnn);
                    SQLConnectiondb.cnn.Open();
                    command.ExecuteNonQuery();               
                    MessageBox.Show(" Book Record Delete Successfully", "Book Delete", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    SQLConnectiondb.cnn.Close();
                }
                catch (Exception e)
                {
                    MessageBox.Show(e.Message);
                }
            }
        }
        private void ClearData()
        {
            txtbookid.Clear();
            cbobookidtype.SelectedIndex = 0;
            txtqty.ResetText();
            txtbookname.Clear();
            txtbookdeatil.Clear();
        }
        private void txtsearch_TextChanged(object sender, EventArgs e)
        {
            SearchData();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            InsertData();
            ViewData();
            ClearData();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            DeleteData();
            ViewData();
            ClearData();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            UpdateData();
            ViewData();
            ClearData();
        }

        private void gunaDataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if(gunaDataGridView1.Rows[e.RowIndex].Cells[e.ColumnIndex].Value != null)
            {
                gunaDataGridView1.CurrentCell.Selected = true;
              txtbookid.Text= gunaDataGridView1.Rows[e.RowIndex].Cells[0].Value.ToString();
             cbobookidtype.Text= gunaDataGridView1.Rows[e.RowIndex].Cells[1].Value.ToString();

                txtbookname.Text = gunaDataGridView1.Rows[e.RowIndex].Cells[3].Value.ToString();
                txtbookdeatil.Text = gunaDataGridView1.Rows[e.RowIndex].Cells[4].Value.ToString();

            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            frmtypeofbookRp frmtypeofbookRp = new frmtypeofbookRp();
            frmtypeofbookRp.Show();
            frmtypeofbookRp.Refresh();
        }
    }
}
