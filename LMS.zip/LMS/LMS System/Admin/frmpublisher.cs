﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using LMS_System.Database;

namespace LMS_System.Admin
{
    public partial class frmpublisher : Form
    {
        String sex;
        public frmpublisher()
        {
            InitializeComponent();
        }

        private void frmpublisher_Load(object sender, EventArgs e)
        {
            SQLConnectiondb sQLConnectiondb = new SQLConnectiondb();
            sQLConnectiondb.DatabaseConnection();
            //view data
            Getdata();
        }
        //GetData
        private void Getdata()
        {
           
            try
            {
                SqlCommand command = new SqlCommand("select * from tblpublisher", SQLConnectiondb.cnn);
                SQLConnectiondb.cnn.Open();
                SqlDataAdapter adapter = new SqlDataAdapter(command);
                DataTable table = new DataTable();
                adapter.Fill(table);
                gunaDataGridView1.DataSource = table;
            }
            catch (Exception e)
            {

                MessageBox.Show(e.Message);
            }
            finally
            {
                SQLConnectiondb.cnn.Close();
            }
        }
        //Insert Record
        private void Insertdata()
        {

            //validate Empty Textbox Record
            if(string.IsNullOrEmpty(txtpubid.Text) && string.IsNullOrEmpty(txtpubname.Text) && string.IsNullOrEmpty(sex) )
            {
                MessageBox.Show("Please Complate Information !", "Complate Information", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                txtpubid.Focus();
                return;
            }
            else
            {
                SqlCommand command = new SqlCommand("Select * from tblpublisher where publisherid='"+txtpubid.Text+"'", SQLConnectiondb.cnn);
                SqlDataAdapter adapter = new SqlDataAdapter(command);
                DataSet dataSet = new DataSet();
                adapter.Fill(dataSet);
                int i = dataSet.Tables[0].Rows.Count;
                if (i > 0)
                {
                    MessageBox.Show(" This Record Exists", "Exists Record", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    dataSet.Clear();
                    return;
                }

            }
            try
            {
                SqlCommand command = new SqlCommand("Insert into tblpublisher (publisherid,publishername,gender,dob,pob,address,tel,email) " +
                    "values(@publisherid,@publishername,@gender,@dob,@pob,@address,@tel,@email)", SQLConnectiondb.cnn);
                SQLConnectiondb.cnn.Open();
                command.Parameters.AddWithValue("@publisherid", txtpubid.Text);
                command.Parameters.AddWithValue("@publishername",txtpubname.Text);
                command.Parameters.AddWithValue("@gender",sex);
                command.Parameters.AddWithValue("@dob",txtdate.Text);
                command.Parameters.AddWithValue("@pob",txtpob.Text);
                command.Parameters.AddWithValue("@address",txtaddress.Text);
                command.Parameters.AddWithValue("@tel",txttel.Text);
                command.Parameters.AddWithValue("@email",txtemail.Text);
                command.ExecuteNonQuery();
                MessageBox.Show("Publisher Add New Successfully !", "Add Publisher", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch (Exception e)
            {

                MessageBox.Show(e.Message);
            }
            finally
            {
                SQLConnectiondb.cnn.Close();
            }
        }
        //Delete data
        private void Deletedata()
        {
            if (MessageBox.Show("Do You Want To Delete Student ?", "Question", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
            {
                try
                {
                    SqlCommand command = new SqlCommand("Delete From tblpublisher where publisherid=@publisherid  ", SQLConnectiondb.cnn);
                    SQLConnectiondb.cnn.Open();
                    command.Parameters.AddWithValue("@publisherid", txtpubid.Text);
                    command.ExecuteNonQuery();
                    MessageBox.Show("publisher Delete Successfully !", "Delete publisher", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
                catch (Exception e)
                {

                    MessageBox.Show(e.Message);
                }
                finally
                {
                    SQLConnectiondb.cnn.Close();
                }
            }
        }
        //search Data
        private void SearchData()
        {
            try
            {
                SqlCommand command = new SqlCommand("select * from tblpublisher where publishername like '%" + txtsearch.Text + "%'", SQLConnectiondb.cnn);
                SQLConnectiondb.cnn.Open();
                SqlDataAdapter adapter = new SqlDataAdapter(command);
                DataTable table = new DataTable();
                adapter.Fill(table);
                gunaDataGridView1.DataSource = table;
            }
            catch (Exception e)
            {

                MessageBox.Show(e.Message);
            }
            finally
            {
                SQLConnectiondb.cnn.Close();
            }
        }
        //Update Record
        private void UpdateData()
        {
            if (MessageBox.Show("Do You Want To Update Publisher ?", "Question", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
            {
                try
                {
                    SqlCommand command = new SqlCommand("Update  tblpublisher set publishername=@publishername , gender=@gender,dob=@dob,pob=@pob,address=@address,tel=@tel,email=@email where publisherid=@publisherid  ", SQLConnectiondb.cnn);
                    SQLConnectiondb.cnn.Open();
                    command.Parameters.AddWithValue("@publisherid", txtpubid.Text);
                    command.Parameters.AddWithValue("@publishername", txtpubname.Text);
                    command.Parameters.AddWithValue("@gender", sex);
                    command.Parameters.AddWithValue("@dob", txtdate.Text);
                    command.Parameters.AddWithValue("@pob", txtpob.Text);
                    command.Parameters.AddWithValue("@address", txtaddress.Text);
                    command.Parameters.AddWithValue("@tel", txttel.Text);
                    command.Parameters.AddWithValue("@email", txtemail.Text);
                    command.ExecuteNonQuery();
                    MessageBox.Show("Publisher Update Successfully !", "Update Publisher", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
                catch (Exception e)
                {

                    MessageBox.Show(e.Message);
                }
                finally
                {
                    SQLConnectiondb.cnn.Close();
                }
            }
        }
        private void gunaRadioButton1_CheckedChanged(object sender, EventArgs e)
        {
            sex = "Male";
        }

        private void gunaRadioButton2_CheckedChanged(object sender, EventArgs e)
        {
            sex = "Female";
        }
        //clear data()
        private void cleardata()
        {
            txtpubid.Clear();
            txtpubname.Clear();
            txtaddress.Clear();
            txtpob.Clear();
            txtemail.Clear();
            txttel.Clear();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Insertdata();
            Getdata();
            cleardata();
        }

        private void txtsearch_TextChanged(object sender, EventArgs e)
        {
            SearchData();
        }

        private void gunaDataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (gunaDataGridView1.Rows[e.RowIndex].Cells[e.ColumnIndex].Value != null)
            {
                gunaDataGridView1.CurrentCell.Selected = true;
                txtpubid.Text = gunaDataGridView1.Rows[e.RowIndex].Cells[0].Value.ToString();
                txtpubname.Text = gunaDataGridView1.Rows[e.RowIndex].Cells[1].Value.ToString();
                if (gunaDataGridView1.SelectedRows[0].Cells[2].Value.Equals("Female"))
                    gunaRadioButton2.Checked = true;
                else
                    gunaRadioButton2.Checked = true;

                if (gunaDataGridView1.SelectedRows[0].Cells[3].Value.Equals("Male"))
                    gunaRadioButton1.Checked = true;
                else
                    gunaRadioButton1.Checked = true;
                txtdate.Value = Convert.ToDateTime(gunaDataGridView1.Rows[e.RowIndex].Cells["dob"].Value);
                txtpob.Text = gunaDataGridView1.Rows[e.RowIndex].Cells[5].Value.ToString();
                txtaddress.Text = gunaDataGridView1.Rows[e.RowIndex].Cells[6].Value.ToString();
                txttel.Text = gunaDataGridView1.Rows[e.RowIndex].Cells[7].Value.ToString();
                txtemail.Text = gunaDataGridView1.Rows[e.RowIndex].Cells[8].Value.ToString();
               

            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            UpdateData();
            Getdata();
            cleardata();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            Deletedata();
            Getdata();
            cleardata();
        }

        private void txtpubid_KeyDown(object sender, KeyEventArgs e)
        {
            if(e.KeyCode == Keys.Enter)
            {
                txtpubname.Focus();
            }
        }

        private void txtpubname_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.Handled = !(char.IsLetter(e.KeyChar) || e.KeyChar == (char)Keys.Back || e.KeyChar == (char)Keys.Space || e.KeyChar == (char)Keys.Enter))
            {
                e.Handled = true;
                base.OnKeyPress(e);
                MessageBox.Show("allow Only Letter ", "Allow Only Letter", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }

        private void txtpob_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.Handled = !(char.IsLetter(e.KeyChar) || e.KeyChar == (char)Keys.Back || e.KeyChar == (char)Keys.Space || e.KeyChar == (char)Keys.Enter))
            {
                e.Handled = true;
                base.OnKeyPress(e);
                MessageBox.Show("allow Only Letter ", "Allow Only Letter", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }

        private void txttel_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.Handled = !char.IsDigit(e.KeyChar) && !char.IsControl(e.KeyChar))
            {
                e.Handled = true;
                base.OnKeyPress(e);
                MessageBox.Show("Allow Only number", "Only Number", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }

        private void txtaddress_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.Handled = !(char.IsLetter(e.KeyChar) || e.KeyChar == (char)Keys.Back || e.KeyChar == (char)Keys.Space || e.KeyChar == (char)Keys.Enter))
            {
                e.Handled = true;
                base.OnKeyPress(e);
                MessageBox.Show("allow Only Letter ", "Allow Only Letter", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }
    }
}
