﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using LMS_System.Database;

namespace LMS_System.Admin
{
    public partial class frmmaindashboard : Form
    {
        public frmmaindashboard()
        {
            InitializeComponent();
        }

        private void frmmaindashboard_Load(object sender, EventArgs e)
        {
            SQLConnectiondb connectiondb = new SQLConnectiondb();
            connectiondb.DatabaseConnection();
            QueryBook();
            StudenQuery();
            QueryLibraran();
            Queryborrow();
        }
        private void QueryBook()
        {
          
            try
            {
                SqlCommand command = new SqlCommand("Select count(bookid) from tblbook", SQLConnectiondb.cnn);
                if (SQLConnectiondb.cnn.State == ConnectionState.Closed)
                {
                    SQLConnectiondb.cnn.Open();
                }
                var totalbook = command.ExecuteScalar();
                int u = int.Parse((totalbook).ToString());
                lblbook.Text = u.ToString();
                SQLConnectiondb.cnn.Close();
            }
            catch (Exception e)
            {

                MessageBox.Show(e.Message);
            }
        }
        private void StudenQuery()
        {
            try
            {
                SqlCommand command = new SqlCommand("Select count(studentid) from tblstudent", SQLConnectiondb.cnn);
                SQLConnectiondb.cnn.Open();
                var totalstudent = command.ExecuteScalar();
                int s = int.Parse((totalstudent).ToString());
                lblstudent.Text = s.ToString();
                SQLConnectiondb.cnn.Close();
            }
            catch (Exception e)
            {

                MessageBox.Show(e.Message);
            }
        }
        private void QueryLibraran()
        {
            try
            {
                SqlCommand command = new SqlCommand("Select count(librarianid) from tbllibrarian", SQLConnectiondb.cnn);
                SQLConnectiondb.cnn.Open();
                var totallibrana = command.ExecuteScalar();
                int s = int.Parse((totallibrana).ToString());
                lbllibraran.Text = s.ToString();
                SQLConnectiondb.cnn.Close();
            }
            catch (Exception e)
            {

                MessageBox.Show(e.Message);
            }
        }
        private void Queryborrow()
        {
            try
            {
                SqlCommand command = new SqlCommand("Select count(borrowid) from tblborrow", SQLConnectiondb.cnn);
                SQLConnectiondb.cnn.Open();
                var totalborrow = command.ExecuteScalar();
                int s = int.Parse((totalborrow).ToString());
                lblbookborrow.Text = s.ToString();
                SQLConnectiondb.cnn.Close();
            }
            catch (Exception e)
            {

                MessageBox.Show(e.Message);
            }
        }
        private void button1_Click(object sender, EventArgs e)
        {
            frmmenureport frmmenureport = new frmmenureport();
            frmmenureport.Show();
        }

        private void flowLayoutPanel1_Paint(object sender, PaintEventArgs e)
        {
           
        }
    }
}
