﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using LMS_System.Database;
using LMS_System.User;

namespace LMS_System.Admin
{
    public partial class frmlogin : Form
    {
        public string user;
        public frmlogin()
        {
            InitializeComponent();
        }
        private void CreateLogin()
        {
            try
            {
                SqlCommand command = new SqlCommand("Select * from tbluserlogin where username='"+txtusername.Text+"'  and password='"+txtpassword.Text+"'", SQLConnectiondb.cnn);
                SQLConnectiondb.cnn.Open();
                SqlDataAdapter adapter = new SqlDataAdapter(command);
                DataTable table = new DataTable();
                adapter.Fill(table);
                string selectrole = comboBox1.SelectedItem.ToString();
                if(table.Rows.Count > 0)
                {
                   for(int i=0; i< table.Rows.Count; i++)
                    {
                        if(table.Rows[i]["role"].ToString() == selectrole)
                        {
                            MessageBox.Show("You Login Type: " + table.Rows[i]["role"] ,"Login Successfully", MessageBoxButtons.OK ,MessageBoxIcon.Information);
                            if (comboBox1.SelectedIndex == 1)
                            {
                              
                                LoadingScreen loading = new LoadingScreen();
                                NameUserLogins.uname = txtusername.Text;
                                NameUserLogins.roles = comboBox1.SelectedItem.ToString();
                                loading.Show();
                                this.Hide();
                            }
                            else
                            {
                                frmuserloadingscreen frmuserloadingscreen = new frmuserloadingscreen();
                                NameUserLogins.guest = txtusername.Text;
                                NameUserLogins.rolegust = comboBox1.SelectedItem.ToString();
                                frmuserloadingscreen.Show();
                                this.Hide();
                            }
                        }
                    }
                }
                else
                {
                    MessageBox.Show("Please Check UserName Password And Role !" , "Error Login" ,MessageBoxButtons.OK ,MessageBoxIcon.Error );
                }
            }
            catch (Exception e)
            {

                MessageBox.Show(e.Message);
            }
            finally
            {
                SQLConnectiondb.cnn.Close();
            }
        }
        private void button1_Click(object sender, EventArgs e)
        {
            CreateLogin();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void frmlogin_Load(object sender, EventArgs e)
        {
            SQLConnectiondb connectiondb = new SQLConnectiondb();
            connectiondb.DatabaseConnection();
            comboBox1.SelectedIndex = 0;
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }
    }
}
