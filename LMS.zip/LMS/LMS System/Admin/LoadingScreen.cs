﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using LMS_System.Admin;

namespace LMS_System.Admin
{
    public partial class LoadingScreen : Form
    {
        public LoadingScreen()
        {
            InitializeComponent();
        }

        private void LoadingScreen_Load(object sender, EventArgs e)
        {
            timer1.Start();
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            {
                //create progress bar  loding
                if (gunaProgressBar1.Value < 100)
                {
                    gunaProgressBar1.Value +=3 ;
                    lblpercent.Text = gunaProgressBar1.Value.ToString() + "%";
                }
                else
                {
                    timer1.Stop();
                    frmdashboardadmin frmdashboardadmin = new frmdashboardadmin();
                    frmdashboardadmin.Show();
                    this.Hide();
                }

            }
        }
    }
}
