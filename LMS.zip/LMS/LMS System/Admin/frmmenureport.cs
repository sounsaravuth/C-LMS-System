﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using LMS_System.Admin.FormReport;

namespace LMS_System.Admin
{
    public partial class frmmenureport : Form
    {
        public frmmenureport()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            frmstudentRP frmstudentRP = new frmstudentRP();
            frmstudentRP.Show();
            frmstudentRP.Refresh();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            frmpubliserRp frmpubliserRp = new frmpubliserRp();
            frmpubliserRp.Show();
            frmpubliserRp.Refresh();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            frmtypeofbookRp frmtypeofbookRp = new frmtypeofbookRp();
            frmtypeofbookRp.Show();
            frmtypeofbookRp.Refresh();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            frmLibrarianRp frmLibrarianRp = new frmLibrarianRp();
            frmLibrarianRp.Show();
            frmLibrarianRp.Refresh();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            frmbookborrow frmbookborrow = new frmbookborrow();
            frmbookborrow.Show();
            frmbookborrow.Refresh();
        }
    }
}
