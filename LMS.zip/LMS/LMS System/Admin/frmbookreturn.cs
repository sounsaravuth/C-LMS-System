﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using LMS_System.Database;

namespace LMS_System.Admin
{
    public partial class frmbookreturn : Form
    {
        public frmbookreturn()
        {
            InitializeComponent();
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void frmbookreturn_Load(object sender, EventArgs e)
        {
            SQLConnectiondb connectiondb = new SQLConnectiondb();
            connectiondb.DatabaseConnection();
            GetData();
            cbostudentid.Items.Add("Select Student ID");
            cbostudentid.SelectedIndex = 0;
            FectchRecoredStudentID();
            cbolibraranid.Items.Add("Select Libraran ID");
            cbolibraranid.SelectedIndex = 0;
            FectchRecoredLibraranID();
            cbobookid.Items.Add("Select Book ID");
            cbobookid.SelectedIndex = 0;
            FectchRecoredBookID();
        }
        private void FectchRecoredBookID()
        {
            SqlCommand command = new SqlCommand("Select * from tblbook", SQLConnectiondb.cnn);
            SQLConnectiondb.cnn.Open();
            SqlDataReader reader = command.ExecuteReader();
            while (reader.Read())
            {
                cbobookid.Items.Add(reader[0]);
            }
            SQLConnectiondb.cnn.Close();
        }
        private void FectchRecoredStudentID()
        {
            SqlCommand command = new SqlCommand("Select * from tblstudent", SQLConnectiondb.cnn);
            SQLConnectiondb.cnn.Open();
            SqlDataReader reader = command.ExecuteReader();
            while (reader.Read())
            {
                cbostudentid.Items.Add(reader[0]);
            }
            SQLConnectiondb.cnn.Close();
        }
        private void FectchRecoredLibraranID()
        {
            SqlCommand command = new SqlCommand("Select * from tbllibrarian", SQLConnectiondb.cnn);
            SQLConnectiondb.cnn.Open();
            SqlDataReader reader = command.ExecuteReader();
            while (reader.Read())
            {
                cbolibraranid.Items.Add(reader[0]);
            }
            SQLConnectiondb.cnn.Close();
        }
        private void GetData()
        {
            try
            {
                SqlCommand command = new SqlCommand("Select * from tblreturn", SQLConnectiondb.cnn);
                SQLConnectiondb.cnn.Open();
                SqlDataAdapter adapter = new SqlDataAdapter(command);
                DataTable table = new DataTable();
                adapter.Fill(table);
                gunaDataGridView1.DataSource = table;
                SQLConnectiondb.cnn.Close();
            }
            catch (Exception e)
            {

                MessageBox.Show(e.Message);
            }
        }
        private void InsertRecord()
        {
            if(string.IsNullOrEmpty(txtreturnid.Text) && string.IsNullOrEmpty(cbostudentid.SelectedItem.ToString()))
            {
                MessageBox.Show("Please Complate Information !", "Complate Information", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }
            else
            {
                SqlCommand command = new SqlCommand("Select * from tblreturn where returnid='"+txtreturnid.Text+"'", SQLConnectiondb.cnn);
                SqlDataAdapter adapter = new SqlDataAdapter(command);
                DataSet dataSet = new DataSet();
                adapter.Fill(dataSet);
                int i = dataSet.Tables[0].Rows.Count;
                if (i > 0)
                {
                    MessageBox.Show(" This Record Exists", "Exists Record", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    dataSet.Clear();
                    return;
                }

            }
            try
            {
                SqlCommand command = new SqlCommand("Insert into tblreturn (returnid,studentid,librarianid,bookid,phnumberreturn,returndate) " +
                    "values(@returnid,@studentid,@librarianid,@bookid,@phnumberreturn,@returndate)", SQLConnectiondb.cnn);
                SQLConnectiondb.cnn.Open();
                command.Parameters.AddWithValue("@returnid" , txtreturnid.Text);
                command.Parameters.AddWithValue("@studentid", cbostudentid.SelectedItem.ToString());
                command.Parameters.AddWithValue("@librarianid",cbolibraranid.SelectedItem.ToString());
                command.Parameters.AddWithValue("@bookid", cbobookid.SelectedItem.ToString());          
                command.Parameters.AddWithValue("@phnumberreturn",txtqty.Value);
                command.Parameters.AddWithValue("@returndate" , txtdatereturn.Text);
                command.ExecuteNonQuery();
                SQLConnectiondb.cnn.Close();
                MessageBox.Show("Book Return !", "Return Book", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch (Exception e)
            {

                MessageBox.Show(e.Message);
            }
        }
        private void UpdateRecord()
        {
            if(MessageBox.Show("Do You Want To Update Record Return ?", "Update Record" , MessageBoxButtons.YesNo ,MessageBoxIcon.Question) == DialogResult.Yes)
            {
                try
                {
                    SqlCommand command = new SqlCommand("Update tblreturn set studentid=@studentid ,librarianid=@librarianid,bookid=@bookid,phnumberreturn=@phnumberreturn,returndate=@returndate",SQLConnectiondb.cnn);
                    SQLConnectiondb.cnn.Open();
                    command.Parameters.AddWithValue("@returnid", txtreturnid.Text);
                    command.Parameters.AddWithValue("@studentid", cbostudentid.SelectedItem.ToString());
                    command.Parameters.AddWithValue("@librarianid", cbolibraranid.SelectedItem.ToString());
                    command.Parameters.AddWithValue("@bookid", cbobookid.SelectedItem.ToString());
                    command.Parameters.AddWithValue("@phnumberreturn", txtqty.Value);
                    command.ExecuteNonQuery();
                    SQLConnectiondb.cnn.Close();
                    MessageBox.Show("Book Return Update !", "Return Book Update", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
                catch (Exception e)
                {

                    MessageBox.Show(e.Message);
                }
            }
        }
     
        private void ClearData()
        {
            txtreturnid.Clear();
            txtqty.ResetText();
            cbostudentid.SelectedIndex = 0;
            cbolibraranid.SelectedIndex = 0;
            cbobookid.SelectedIndex = 0;
        }
        private void button1_Click(object sender, EventArgs e)
        {
            InsertRecord();
            GetData();
            ClearData();
          
        }

        private void button5_Click(object sender, EventArgs e)
        {
          
        }

        private void button5_Click_1(object sender, EventArgs e)
        {
           
        }

        private void button4_Click(object sender, EventArgs e)
        {
           
        }
    }
}
