﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace LMS_System.Admin.FormReport
{
    public partial class frmtypeofbookRp : Form
    {
        public frmtypeofbookRp()
        {
            InitializeComponent();
        }

        private void frmtypeofbookRp_Load(object sender, EventArgs e)
        {
            crystalReportViewer1.RefreshReport();
            crystalReportViewer1.Zoom(100);
        }
    }
}
