﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using LMS_System.Database;

namespace LMS_System.Admin
{
    public partial class frmbook : Form
    {
        public frmbook()
        {
            InitializeComponent();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            frmbooktype frmbooktype = new frmbooktype();
            frmbooktype.Show();
        }

        private void frmbook_Load(object sender, EventArgs e)
        {
            SQLConnectiondb connectiondb = new SQLConnectiondb();
            connectiondb.DatabaseConnection();
            cbobooktype.Items.Add("Choose BookType ID");
            cbobooktype.SelectedIndex = 0;
            FetchRecordBookType();
            GetData();
            
        }
        //Fetch Record From Table BookType
        private void FetchRecordBookType()
        {
            try
            {
                SqlCommand command = new SqlCommand("Select * from tblbooktype", SQLConnectiondb.cnn);
                SQLConnectiondb.cnn.Open();
                SqlDataReader reader = command.ExecuteReader();
                while (reader.Read())
                {
                    cbobooktype.Items.Add(reader[0]);
                }
                
            }
            catch (Exception e)
            {
                MessageBox.Show(e.Message);
                
            }
            finally
            {
                SQLConnectiondb.cnn.Close();
            }
        }
        private void GetData()
        {
            try
            {
                SqlCommand command = new SqlCommand("Select * from tblbook", SQLConnectiondb.cnn);
                SQLConnectiondb.cnn.Open();
                SqlDataAdapter adapter = new SqlDataAdapter(command);
                DataTable table = new DataTable();
                adapter.Fill(table);
                gunaDataGridView1.DataSource = table;
                    
            }
            catch (Exception e)
            {

                MessageBox.Show(e.Message);
            }
            finally
            {
                SQLConnectiondb.cnn.Close();
            }
        }
        private void InsertData()
        {
            if(string.IsNullOrEmpty(txtbookid.Text) && string.IsNullOrEmpty(cbobooktype.Text) && string.IsNullOrEmpty(txtbookname.Text))
            {
                MessageBox.Show("Please Complate Book Information !", "complate Information", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                txtbookid.Focus();
                return;
            }
            else
            {
                SqlCommand command = new SqlCommand("Select * from tblbook where bookid='"+txtbookid.Text+"'", SQLConnectiondb.cnn);
                SqlDataAdapter adapter = new SqlDataAdapter(command);
                DataSet ds = new DataSet();
                adapter.Fill(ds);
                int i = ds.Tables[0].Rows.Count;
                if(i > 0)
                {
                    MessageBox.Show("This Record Exist !" , "Record Extist" , MessageBoxButtons.OK,MessageBoxIcon.Warning);
                    ds.Clear();
                    return;
                }
            }
            try
            {
                SqlCommand command = new SqlCommand("Insert into tblbook (bookid,booktypeid,qty,bookname,description) " +
                    "values(@bookid,@booktypeid,@qty,@bookname,@description)", SQLConnectiondb.cnn);
                SQLConnectiondb.cnn.Open();
                command.Parameters.AddWithValue("@bookid",txtbookid.Text);
                command.Parameters.AddWithValue("@booktypeid",cbobooktype.Text);
                command.Parameters.AddWithValue("@qty", txtqty.Value);
                command.Parameters.AddWithValue("@bookname",txtbookname.Text);
                command.Parameters.AddWithValue("@description",txtdeatil.Text);
                command.ExecuteNonQuery();
                MessageBox.Show("Book Add New Successfully", "Add New Book", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch (Exception e)
            {

                MessageBox.Show(e.Message);
            }
            finally
            {
                SQLConnectiondb.cnn.Close();
            }
        }
        private void Clear()
        {
            txtbookid.Clear();
            txtbookname.Clear();
            txtdeatil.Clear();
            txtqty.ResetText();
            cbobooktype.SelectedIndex = 0;
        }
        private void DeleteData()
        {
            if(MessageBox.Show("Do You want To Delete Book Record ?" , "Delete Book Record" , MessageBoxButtons.YesNo , MessageBoxIcon.Question) == DialogResult.Yes)
            {
                try
                {
                    SqlCommand command = new SqlCommand("Delete From tblbook where bookid=@bookid", SQLConnectiondb.cnn);
                    SQLConnectiondb.cnn.Open();
                    command.Parameters.AddWithValue("@bookid", txtbookid.Text);
                    command.ExecuteNonQuery();
                    MessageBox.Show("Book Record Delete Successfully", "Delete Book", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
                catch (Exception e)
                {

                    MessageBox.Show(e.Message);
                }
                finally
                {
                    SQLConnectiondb.cnn.Close();
                }
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            InsertData();
            GetData();
            Clear();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            DeleteData();
            GetData();
            Clear();
        }
        private void UpdateBook ()
        {
            if (MessageBox.Show("Do You want To Update Book Record ?", "Update Book Record", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
            {
                try
                {
                    SqlCommand command = new SqlCommand("Update tblbook set  booktypeid=@booktypeid ,qty=@qty ,bookname=@bookname , description=@description where bookid=@bookid ", SQLConnectiondb.cnn);
                    SQLConnectiondb.cnn.Open();
                    command.Parameters.AddWithValue("@bookid", txtbookid.Text);
                    command.Parameters.AddWithValue("@booktypeid", cbobooktype.Text);
                    command.Parameters.AddWithValue("@qty", txtqty.Value);
                    command.Parameters.AddWithValue("@bookname", txtbookname.Text);
                    command.Parameters.AddWithValue("@description", txtdeatil.Text);
                    command.ExecuteNonQuery();
                    MessageBox.Show("Book Update Successfully", "Update Book", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
                catch (Exception e)
                {

                    MessageBox.Show(e.Message);
                }
                finally
                {
                    SQLConnectiondb.cnn.Close();
                }
            }



        }
        private void gunaDataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if(gunaDataGridView1.Rows[e.RowIndex].Cells[e.ColumnIndex].Value != null)
            {
                gunaDataGridView1.CurrentCell.Selected = true;
                txtbookid.Text = gunaDataGridView1.Rows[e.RowIndex].Cells[0].Value.ToString();
                cbobooktype.SelectedItem = gunaDataGridView1.Rows[e.RowIndex].Cells[1].Value.ToString();
                txtbookname.Text = gunaDataGridView1.Rows[e.RowIndex].Cells[3].Value.ToString();
                txtdeatil.Text = gunaDataGridView1.Rows[e.RowIndex].Cells[4].Value.ToString();
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            UpdateBook();
            GetData();
            Clear();
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            SearchData();
        }
        private void SearchData()
        {
            try
            {
                SqlCommand command = new SqlCommand("Select * from tblbook where bookname like '%"+txtsearch.Text+"%'", SQLConnectiondb.cnn);
                SQLConnectiondb.cnn.Open();
                SqlDataAdapter adapter = new SqlDataAdapter(command);
                DataTable table = new DataTable();
                adapter.Fill(table);
                gunaDataGridView1.DataSource = table;
            }
            catch (Exception e)
            {

                MessageBox.Show(e.Message);
            }
            finally
            {
                SQLConnectiondb.cnn.Close();
            }
        }

        private void button5_Click(object sender, EventArgs e)
        {
            frmbookauthor frmbookauthor = new frmbookauthor();
            frmbookauthor.Show();
        }

        private void gunaDataGridView1_DataError(object sender, DataGridViewDataErrorEventArgs e)
        {
            if (e.Exception.Message == "DataGridView Validating")
            {
                object value = gunaDataGridView1.Rows[e.RowIndex].Cells[e.ColumnIndex].Value;
                if (!((DataGridViewComboBoxColumn)gunaDataGridView1.Columns[e.ColumnIndex]).Items.Contains(value))
                {
                    ((DataGridViewComboBoxColumn)gunaDataGridView1.Columns[e.ColumnIndex]).Items.Add(value);
                    e.ThrowException = false;
                }
            }
        }

        private void button6_Click(object sender, EventArgs e)
        {
            Clear();
        }
    }
}
