﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using LMS_System.Database;

namespace LMS_System.Admin
{
    public partial class frmbookauthor : Form
    {
        public frmbookauthor()
        {
            InitializeComponent();
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void frmbookauthor_Load(object sender, EventArgs e)
        {
            SQLConnectiondb connectiondb = new SQLConnectiondb();
            connectiondb.DatabaseConnection();
            GetDatas();
            cbobookid.Items.Add("select Book ID");
            cbobookid.SelectedIndex = 0;
            FetchRecordbookid();

            cboauthorid.Items.Add("Select Author ID");
            cboauthorid.SelectedIndex = 0;
            FetchRecordAuthorid();

        }
        private void FetchRecordbookid()
        {
            SqlCommand command = new SqlCommand("Select * from tblbook",SQLConnectiondb.cnn);
            SQLConnectiondb.cnn.Open();
            SqlDataReader reader = command.ExecuteReader();
            
            while (reader.Read())
            {
                cbobookid.Items.Add(reader[0]);
            }
            SQLConnectiondb.cnn.Close();
        }
        private void FetchRecordAuthorid()
        {
            SqlCommand command = new SqlCommand("Select * from tblauthor", SQLConnectiondb.cnn);
            SQLConnectiondb.cnn.Open();
            SqlDataReader reader = command.ExecuteReader();
            while (reader.Read())
            {
                cboauthorid.Items.Add(reader[0]);
            }
            SQLConnectiondb.cnn.Close();
        }
        private void GetDatas()
        {
            try
            {
                SqlCommand command = new SqlCommand("Select * from Bookauthor", SQLConnectiondb.cnn);
                SQLConnectiondb.cnn.Open();
                SqlDataAdapter adapter = new SqlDataAdapter(command);
                DataTable table = new DataTable();
                adapter.Fill(table);
                gunaDataGridView1.DataSource = table;
            }
            catch (Exception e)
            {

                MessageBox.Show(e.Message);
            }
            finally
            {
                SQLConnectiondb.cnn.Close();
            }
        }
        private void InsertData()
        {
            if(string.IsNullOrEmpty(cbobookid.SelectedItem.ToString()) && string.IsNullOrEmpty(cboauthorid.SelectedItem.ToString()))
            {
                MessageBox.Show("Complate Information", "Complate Information", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }
            else
            {
                SqlCommand command = new SqlCommand("Select * from Bookauthor where bookid='"+cbobookid.SelectedItem.ToString()+"'", SQLConnectiondb.cnn);
                SqlDataAdapter adapter = new SqlDataAdapter(command);
                DataSet dataSet = new DataSet();
                adapter.Fill(dataSet);
                int i = dataSet.Tables[0].Rows.Count;
                if(i > 0)
                {
                    MessageBox.Show(" This Record Exist !", "Record Exist", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    dataSet.Clear();
                    return;
                }
            }
            try
            {
                SqlCommand command = new SqlCommand("Insert into Bookauthor (bookid,authorid,authordate,notes)" +
                    " values(@bookid,@authorid,@authordate,@notes)", SQLConnectiondb.cnn);
                SQLConnectiondb.cnn.Open();
                command.Parameters.AddWithValue("@bookid", cbobookid.SelectedItem.ToString());
                command.Parameters.AddWithValue("@authorid", cboauthorid.SelectedItem.ToString());
                command.Parameters.AddWithValue("@authordate", txtdate.Text);
                command.Parameters.AddWithValue("@notes", txtnote.Text);
                command.ExecuteNonQuery();
                MessageBox.Show("Book Author Save" , "Author Save" , MessageBoxButtons.OK,MessageBoxIcon.Information);
            }
            catch (Exception e)
            {

                MessageBox.Show(e.Message);
            }
            finally
            {
                SQLConnectiondb.cnn.Close();
            }
        }
        private void DeleteData()
        {
          if(MessageBox.Show("Do You Want To Delete Book Author ? " , "Question" , MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
            {
                try
                {
                    SqlCommand command = new SqlCommand("Delete from Bookauthor where bookid=@bookid", SQLConnectiondb.cnn);
                    SQLConnectiondb.cnn.Open();
                    command.Parameters.AddWithValue("@bookid" , cbobookid.SelectedItem.ToString());
                    command.ExecuteNonQuery();
                    MessageBox.Show("Author Book Delete " , "Author Book Delete" , MessageBoxButtons.OK , MessageBoxIcon.Information);
                }
                catch (Exception e)
                {

                    MessageBox.Show(e.Message);
                }
                finally
                {
                    SQLConnectiondb.cnn.Close();
                }
            }
        }
        private void UpdateData()
        {
            if (MessageBox.Show("Do You Want To Delete Book Author ? ", "Question", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
            {
                try
                {
                    SqlCommand command = new SqlCommand("Update Bookauthor set authorid=@authorid , authordate=@authordate, notes=@notes where bookid=@bookid", SQLConnectiondb.cnn);
                    SQLConnectiondb.cnn.Open();
                    command.Parameters.AddWithValue("@bookid", cbobookid.SelectedItem.ToString());
                    command.Parameters.AddWithValue("@authorid", cboauthorid.SelectedItem.ToString());
                    command.Parameters.AddWithValue("@authordate", txtdate.Text);
                    command.Parameters.AddWithValue("@notes", txtnote.Text);
                    command.ExecuteNonQuery();
                    MessageBox.Show("Book Author Update", "Author Update", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
                catch (Exception e)
                {

                    MessageBox.Show(e.Message);
                }
                finally
                {
                    SQLConnectiondb.cnn.Close();
                }
            }
        }
        private void Clear()
        {
            cbobookid.SelectedIndex = 0;
            cboauthorid.SelectedIndex = 0;
            txtnote.Clear();
        }
        private void SearchData()
        {
            try
            {
                SqlCommand command = new SqlCommand("Select * from Bookauthor where bookid Like'%"+txtsearch.Text+"%'", SQLConnectiondb.cnn);
                SQLConnectiondb.cnn.Open();
                SqlDataAdapter adapter = new SqlDataAdapter(command);
                DataTable table = new DataTable();
                adapter.Fill(table);
                gunaDataGridView1.DataSource = table;
            }
            catch (Exception ex)
            {

                MessageBox.Show(ex.Message);
            }
            finally
            {
                SQLConnectiondb.cnn.Close();
            }
        }
        private void cbobookid_SelectedIndexChanged(object sender, EventArgs e)
        {
           
        }

        private void button1_Click(object sender, EventArgs e)
        {
            InsertData();
            GetDatas();
            Clear();

        }

        private void button3_Click(object sender, EventArgs e)
        {
            DeleteData();
            GetDatas();
            Clear();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            frmbook frmbook = new frmbook();
            frmbook.Show();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            frmauthor frmauthor = new frmauthor();
            frmauthor.Show();
        }

        private void gunaDataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if(gunaDataGridView1.Rows[e.RowIndex].Cells[e.ColumnIndex].Value != null)
            {
                gunaDataGridView1.CurrentCell.Selected = true;
                cbobookid.SelectedItem = gunaDataGridView1.Rows[e.RowIndex].Cells[0].Value.ToString();
                cboauthorid.SelectedItem = gunaDataGridView1.Rows[e.RowIndex].Cells[1].Value.ToString();
                txtdate.Value = Convert.ToDateTime(gunaDataGridView1.Rows[e.RowIndex].Cells["authordate"].Value);
                txtnote.Text = gunaDataGridView1.Rows[e.RowIndex].Cells[3].Value.ToString();
            }
        }

        private void txtsearch_TextChanged(object sender, EventArgs e)
        {
            SearchData();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            UpdateData();
            GetDatas();
            Clear();
        }
    }
}
