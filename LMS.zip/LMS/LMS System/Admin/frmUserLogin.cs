﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using LMS_System.Database;

namespace LMS_System.Admin
{
    public partial class frmUserLogin : Form
    {
        public frmUserLogin()
        {
            InitializeComponent();
        }

        private void frmUserLogin_Load(object sender, EventArgs e)
        {
            SQLConnectiondb connectiondb = new SQLConnectiondb();
            connectiondb.DatabaseConnection();
            ViewData();
            cborole.Items.Add("Select Role");
            cborole.Items.Add("Admin");
            cborole.Items.Add("User");
            cborole.SelectedIndex = 0;
        }
        private void ViewData()
        {
            try
            {
                SqlCommand command = new SqlCommand("exec SP_UserLoginViewData", SQLConnectiondb.cnn);
                SQLConnectiondb.cnn.Open();
                SqlDataAdapter adapter = new SqlDataAdapter(command);
                DataTable table = new DataTable();
                adapter.Fill(table);
                gunaDataGridView1.DataSource = table;
                SQLConnectiondb.cnn.Close();
            }
            catch (Exception e)
            {
                MessageBox.Show(e.Message);
            }
        }
        private void Createuser()
        {
            if(string.IsNullOrEmpty(txtuserid.Text) && string.IsNullOrEmpty(txtusername.Text) && string.IsNullOrEmpty(txtpassword.Text) && string.IsNullOrEmpty(cborole.Text))
            {
                MessageBox.Show("Please Complate Information !", "Complate Information", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }
            else
            {
                SqlCommand command1 = new SqlCommand("Select * from tbluserlogin where userid='"+txtuserid.Text+"'", SQLConnectiondb.cnn);
                SqlDataAdapter adapter = new SqlDataAdapter(command1);
                DataSet dataSet = new DataSet();
                adapter.Fill(dataSet);
                int i = dataSet.Tables[0].Rows.Count;
                if(i > 0)
                {
                    MessageBox.Show("Record Extist" , "Extist Record" , MessageBoxButtons.OK ,MessageBoxIcon.Warning);
                    dataSet.Clear();
                    return;
                }
            }
         
            try
            {
                SqlCommand command = new SqlCommand("exec SP_UserLoginCreate'" + txtuserid.Text + "' , '" + txtusername.Text + "','" + txtpassword.Text + "','" + cborole.Text + "'", SQLConnectiondb.cnn);
                SQLConnectiondb.cnn.Open();
                command.ExecuteNonQuery();
                SQLConnectiondb.cnn.Close();
                MessageBox.Show("User Create Successfully", "User Create", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch (Exception e)
            {

                MessageBox.Show(e.Message);
            }
        }
        private void UpdateUser()
        {
            if(MessageBox.Show("Do You Want To Update User ?" , "Question" , MessageBoxButtons.YesNo , MessageBoxIcon.Question) == DialogResult.Yes)
            {
                try
                {
                    SqlCommand command = new SqlCommand("exec SP_UserLoginUpdate'" + txtuserid.Text + "' , '" + txtusername.Text + "','" + txtpassword.Text + "','" + cborole.Text + "'", SQLConnectiondb.cnn);
                    SQLConnectiondb.cnn.Open();
                    command.ExecuteNonQuery();
                    SQLConnectiondb.cnn.Close();
                    MessageBox.Show("User Update Successfully", "User Update", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
                catch (Exception e)
                {

                    MessageBox.Show(e.Message);
                }
            }
         
           
        }
        private void DeleteUser()
        {
            if (MessageBox.Show("Do You Want To Update User ?", "Question", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
            {
                try
                {
                    SqlCommand command = new SqlCommand("exec SP_UserLoginDelete'" + txtuserid.Text + "'", SQLConnectiondb.cnn);
                    SQLConnectiondb.cnn.Open();
                    command.ExecuteNonQuery();
                    SQLConnectiondb.cnn.Close();
                    MessageBox.Show("User Delete Successfully", "User Delete", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
                catch (Exception e)
                {

                    MessageBox.Show(e.Message);
                }
            }
          
        }

        private void gunaDataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if(gunaDataGridView1.Rows[e.RowIndex].Cells[e.ColumnIndex].Value != null)
            {
                gunaDataGridView1.CurrentCell.Selected = true;
                txtuserid.Text = gunaDataGridView1.Rows[e.RowIndex].Cells[0].Value.ToString();
                txtusername.Text = gunaDataGridView1.Rows[e.RowIndex].Cells[1].Value.ToString();
                txtpassword.Text = gunaDataGridView1.Rows[e.RowIndex].Cells[2].Value.ToString();
                cborole.Text = gunaDataGridView1.Rows[e.RowIndex].Cells[3].Value.ToString();
            }
        }
        private void ClearData()
        {

            txtuserid.Clear();
            txtusername.Clear();
            txtpassword.Clear();
            cborole.SelectedIndex = 0;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Createuser();
            ViewData();
            ClearData();

        }

        private void button2_Click(object sender, EventArgs e)
        {
            UpdateUser();
            ViewData();
            ClearData();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            DeleteUser();
            ViewData();
            ClearData();
        }
    }
}
