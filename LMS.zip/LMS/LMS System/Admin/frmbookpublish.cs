﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using LMS_System.Database;
namespace LMS_System.Admin
{
    public partial class frmbookpublish : Form
    {
        public frmbookpublish()
        {
            InitializeComponent();
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void frmbookpublish_Load(object sender, EventArgs e)
        {
            SQLConnectiondb connectiondb = new SQLConnectiondb();
            connectiondb.DatabaseConnection();
            GetData();
            cbobookid.Items.Add("Select Book ID");
            cbobookid.SelectedIndex = 0;
            FectchRecordBookid();
            cbopubid.Items.Add("Select Publiser ID");
            cbopubid.SelectedIndex = 0;
            FectchRecordpubliserid();
        }
        private void FectchRecordBookid()
        {
            SqlCommand command = new SqlCommand("Select * from tblbook", SQLConnectiondb.cnn);
            SQLConnectiondb.cnn.Open();
            SqlDataReader reader = command.ExecuteReader();
            while (reader.Read())
            {
                cbobookid.Items.Add(reader[0]);
            }
            SQLConnectiondb.cnn.Close();
        }
        private void FectchRecordpubliserid()
        {
            SqlCommand command = new SqlCommand("Select * from tblpublisher", SQLConnectiondb.cnn);
            SQLConnectiondb.cnn.Open();
            SqlDataReader reader = command.ExecuteReader();
            while (reader.Read())
            {
                cbopubid.Items.Add(reader[0]);
            }
            SQLConnectiondb.cnn.Close();
        }
        private void Clear()
        {
            cbobookid.SelectedIndex = 0;
            cbopubid.SelectedIndex = 0;
            txtnumb.Clear();
            txtnote.Clear();
        }
        private void GetData()
        {
            try
            {
                SqlCommand command = new SqlCommand("Select * from tblbookpublish", SQLConnectiondb.cnn);
                SQLConnectiondb.cnn.Open();
                SqlDataAdapter adapter = new SqlDataAdapter(command);
                DataTable table = new DataTable();
                adapter.Fill(table);
                gunaDataGridView1.DataSource = table;
                SQLConnectiondb.cnn.Close();
                    
            }
            catch (Exception e)
            {

                MessageBox.Show(e.Message);
            }
        }
        private void InsertRecord()
        {
            if (string.IsNullOrEmpty(cbobookid.SelectedItem.ToString()) && string.IsNullOrEmpty(cbopubid.SelectedItem.ToString()))
            {
                MessageBox.Show("Please Complate Information", "Complate Information", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }
            else
            {
                SqlCommand command = new SqlCommand("Select * from tblbookpublish where bookid='"+cbobookid.SelectedItem.ToString()+"'", SQLConnectiondb.cnn);
                SqlDataAdapter adapter = new SqlDataAdapter(command);
                DataSet data = new DataSet();
                adapter.Fill(data);
                int i = data.Tables[0].Rows.Count;
                if (i > 0)
                {
                    MessageBox.Show("This Record Extist !","Record Extist" , MessageBoxButtons.OK ,MessageBoxIcon.Warning);
                    data.Clear();
                    return;
                }
            }
            try
            {
                SqlCommand command = new SqlCommand("Insert into tblbookpublish (bookid,publisherid,publishdate,numberpublish,notes) " +
                    "values(@bookid,@publisherid,@publishdate,@numberpublish,@notes)", SQLConnectiondb.cnn);
                SQLConnectiondb.cnn.Open();
                command.Parameters.AddWithValue("@bookid",cbobookid.SelectedItem.ToString());
                command.Parameters.AddWithValue("@publisherid",cbopubid.SelectedItem.ToString());
                command.Parameters.AddWithValue("@publishdate",txtdate.Text);
                command.Parameters.AddWithValue("@numberpublish",txtnumb.Text);
                command.Parameters.AddWithValue("@notes",txtnote.Text);
                command.ExecuteNonQuery();
                MessageBox.Show("Book Publisher Add Successfully", "Book Pubisher", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch (Exception e)
            {

                MessageBox.Show(e.Message);
            }
            finally
            {
                SQLConnectiondb.cnn.Close();
            }
        }
        private void UpdateRecrod()
        {
            if (MessageBox.Show("Do You Want To Delete Book Publisher ?", "Question", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
            {
                try
                {
                    SqlCommand command = new SqlCommand("Update tblbookpublish set publisherid=@publisherid,publishdate=@publishdate,numberpublish=@numberpublish,notes=@notes where bookid=@bookid", SQLConnectiondb.cnn);
                    SQLConnectiondb.cnn.Open();
                    command.Parameters.AddWithValue("@bookid", cbobookid.SelectedItem.ToString());
                    command.Parameters.AddWithValue("@publisherid", cbopubid.SelectedItem.ToString());
                    command.Parameters.AddWithValue("@publishdate", txtdate.Text);
                    command.Parameters.AddWithValue("@numberpublish", txtnumb.Text);
                    command.Parameters.AddWithValue("@notes", txtnote.Text);
                    command.ExecuteNonQuery();
                    MessageBox.Show("Book Publisher Update Successfully", " Update Book Pubisher", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    SQLConnectiondb.cnn.Close();
                }
                catch (Exception e)
                {

                    MessageBox.Show(e.Message);
                }
            }
        }
        private void DeleteRecord()
        {
             if(MessageBox.Show("Do You Want To Delete Book Publisher ?" , "Question" , MessageBoxButtons.YesNo , MessageBoxIcon.Question) == DialogResult.Yes)
            {
                try
                {
                    SqlCommand command = new SqlCommand("Delete from tblbookpublish where bookid=@bookid", SQLConnectiondb.cnn);
                    SQLConnectiondb.cnn.Open();
                    command.Parameters.AddWithValue("@bookid", cbobookid.SelectedItem.ToString ());
                    command.ExecuteNonQuery();
                    MessageBox.Show("Book Publisher Delete Successfully", "Book Pubisher Delete", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
                catch (Exception e)
                {

                    MessageBox.Show(e.Message);
                }
                finally
                {
                    SQLConnectiondb.cnn.Close();
                }
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            InsertRecord();
            Clear();
            GetData();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            DeleteRecord();
            GetData();
            Clear();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            frmbook frmbook = new frmbook();
            frmbook.Show();
        }

        private void gunaDataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if(gunaDataGridView1.Rows[e.RowIndex].Cells[e.ColumnIndex].Value != null)
            {
                gunaDataGridView1.CurrentCell.Selected = true;
                cbobookid.SelectedItem = gunaDataGridView1.Rows[e.RowIndex].Cells[0].Value.ToString();
                cbopubid.SelectedItem = gunaDataGridView1.Rows[e.RowIndex].Cells[1].Value.ToString();
                txtdate.Value = Convert.ToDateTime(gunaDataGridView1.Rows[e.RowIndex].Cells["publishdate"].Value);
                txtnumb.Text = gunaDataGridView1.Rows[e.RowIndex].Cells[3].Value.ToString();
                txtnote.Text = gunaDataGridView1.Rows[e.RowIndex].Cells[4].Value.ToString();
            }
        }
        private void Search()
        {
            try
            {
                SqlCommand command = new SqlCommand("Select * from tblbookpublish where bookid like'%"+txtsearch.Text+"%'" , SQLConnectiondb.cnn);
                SQLConnectiondb.cnn.Open();
                SqlDataAdapter adapter = new SqlDataAdapter(command);
                DataTable table = new DataTable();
                adapter.Fill(table);
                gunaDataGridView1.DataSource = table;
                SQLConnectiondb.cnn.Close();
            }
            catch (Exception e)
            {

                MessageBox.Show(e.Message);
            }
        }
        private void button2_Click(object sender, EventArgs e)
        {
            UpdateRecrod();
            GetData();
            Clear();
        }

        private void txtsearch_TextChanged(object sender, EventArgs e)
        {
            Search();
        }
    }
}
