﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using LMS_System.Database;

namespace LMS_System.Admin
{
    public partial class frmbookborrow : Form
    {
        public frmbookborrow()
        {
            InitializeComponent();
        }

        private void panel2_Paint(object sender, PaintEventArgs e)
        {

        }

        private void frmbookborrow_Load(object sender, EventArgs e)
        {
            SQLConnectiondb connectiondb = new SQLConnectiondb();
            connectiondb.DatabaseConnection();
            GetData();
            cbobookid.Items.Add("Select Book ID");
            cbobookid.SelectedIndex = 0;
            FectchRecoredBookID();
            cbostudentid.Items.Add("Select Student ID");
            cbostudentid.SelectedIndex = 0;
            FectchRecoredStudentID();
            cbolibrarianid.Items.Add("Select Libraran ID");
            cbolibrarianid.SelectedIndex = 0;
            FectchRecoredLibraranID();
          
        }

        private void FectchRecoredBookID()
        {
            SqlCommand command = new SqlCommand("Select * from tblbook", SQLConnectiondb.cnn);
            SQLConnectiondb.cnn.Open();
            SqlDataReader reader = command.ExecuteReader();
            while (reader.Read())
            {
                cbobookid.Items.Add(reader[0]);
            }
            SQLConnectiondb.cnn.Close();
        }
        private void FectchRecoredStudentID()
        {
            SqlCommand command = new SqlCommand("Select * from tblstudent", SQLConnectiondb.cnn);
            SQLConnectiondb.cnn.Open();
            SqlDataReader reader = command.ExecuteReader();
            while (reader.Read())
            {
                cbostudentid.Items.Add(reader[0]);
            }
            SQLConnectiondb.cnn.Close();
        }
        private void FectchRecoredLibraranID()
        {
            SqlCommand command = new SqlCommand("Select * from tbllibrarian", SQLConnectiondb.cnn);
            SQLConnectiondb.cnn.Open();
            SqlDataReader reader = command.ExecuteReader();
            while (reader.Read())
            {
                cbolibrarianid.Items.Add(reader[0]);
            }
            SQLConnectiondb.cnn.Close();
        }
        private void GetData()
        {
            try
            {
                SqlCommand command = new SqlCommand("Select * from tblborrow", SQLConnectiondb.cnn);
                SQLConnectiondb.cnn.Open();
                SqlDataAdapter adapter = new SqlDataAdapter(command);
                DataTable table = new DataTable();
                adapter.Fill(table);
                gunaDataGridView1.DataSource = table;
                SQLConnectiondb.cnn.Close();
            }
            catch (Exception e)
            {

                MessageBox.Show(e.Message);
            }
        }
        private void Clear()
        {
            txtborrowid.Clear();
            cbobookid.SelectedIndex = 0;
            cbostudentid.SelectedIndex = 0;
            cbolibrarianid.SelectedIndex = 0;
            txtqty.ResetText();
          
        }
        private void InsertRecord()
        {
            if(string.IsNullOrEmpty(txtborrowid.Text) && string.IsNullOrEmpty(cbobookid.SelectedItem.ToString()))
            {
                MessageBox.Show("Please Fill Information !", "Complate Information", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                txtborrowid.Focus();
                return;
            }
            else
            {
                SqlCommand command = new SqlCommand("select * from tblborrow where borrowid='" + txtborrowid.Text + "'" , SQLConnectiondb.cnn);
                SqlDataAdapter adapter = new SqlDataAdapter(command);
                DataSet dataSet = new DataSet();
                adapter.Fill(dataSet);
                int i = dataSet.Tables[0].Rows.Count;
                if(i > 0)
                {
                    MessageBox.Show("This Record Exist", "Record Exist", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    dataSet.Clear();
                    return;
                }
            }
            try
            {
                SqlCommand command = new SqlCommand("INSERT INTO tblborrow (borrowid,studentid,librarianid,bookid,phnumberborrow,borrowdate,returndate)" +
                    " values(@borrowid,@studentid,@librarianid,@bookid,@phnumberborrow,@borrowdate,@returndate)", SQLConnectiondb.cnn);
                SQLConnectiondb.cnn.Open();
                command.Parameters.AddWithValue("@borrowid",txtborrowid.Text);
                command.Parameters.AddWithValue("@studentid",cbostudentid.SelectedItem.ToString());
                command.Parameters.AddWithValue("@librarianid" , cbolibrarianid.SelectedItem.ToString());
                command.Parameters.AddWithValue("@bookid",cbobookid.SelectedItem.ToString());      
                command.Parameters.AddWithValue("@phnumberborrow",txtqty.Value.ToString());
                command.Parameters.AddWithValue("@borrowdate", txtdateborrow.Text);
                command.Parameters.AddWithValue("@returndate", txtdatereturn.Text);
                command.ExecuteNonQuery();
                SQLConnectiondb.cnn.Close();
                MessageBox.Show("Book Borrow Save Successfully" , "Book Borrow" , MessageBoxButtons.OK , MessageBoxIcon.Information);
            }
            catch (Exception e)
            {

                MessageBox.Show(e.Message);
            }
        }
        private void DeleteRecord()
        {
            try
            {
                SqlCommand command = new SqlCommand("Delete from tblborrow where borrowid='" + txtborrowid.Text + "'", SQLConnectiondb.cnn);
                SQLConnectiondb.cnn.Open();
                command.Parameters.AddWithValue("@borrowid", txtborrowid.Text);
                command.ExecuteNonQuery();
                SQLConnectiondb.cnn.Close();
                MessageBox.Show("Book Borrow Delete Successfully", "Book Borrow Delete" , MessageBoxButtons.OK ,MessageBoxIcon.Information);
            }
            catch (Exception e)
            {

                MessageBox.Show(e.Message);
            }
        }
        private void UpdateRecord()
        {
            if(MessageBox.Show("Do You Want To Update Book Borrow ?" , "Book Borrow" , MessageBoxButtons.YesNo ,MessageBoxIcon.Question) == DialogResult.Yes)
            {
                try
                {
                    SqlCommand command = new SqlCommand("Update tblborrow set studentid=@studentid,librarianid=@librarianid,bookid=@bookid," +
                        "borrowdate=@borrowdate ,returndate=@returndate , phnumberborrow=@phnumberborrow , deposit=@deposit , remark=@remark where borrowid=@borrowid", SQLConnectiondb.cnn);
                    SQLConnectiondb.cnn.Open();
                    command.Parameters.AddWithValue("@borrowid", txtborrowid.Text);
                    command.Parameters.AddWithValue("@studentid", cbostudentid.SelectedItem.ToString());
                    command.Parameters.AddWithValue("@librarianid", cbolibrarianid.SelectedItem.ToString());
                    command.Parameters.AddWithValue("@bookid", cbobookid.SelectedItem.ToString());
    
                    command.Parameters.AddWithValue("@phnumberborrow", txtqty.Value.ToString());
                    command.Parameters.AddWithValue("@borrowdate", txtdateborrow.Text);
                    command.Parameters.AddWithValue("@returndate", txtdatereturn.Text);
                    command.ExecuteNonQuery();
                    SQLConnectiondb.cnn.Close();
                    MessageBox.Show("Book Borrow Update Successfully", "Book Borrow Update", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
                catch (Exception e)
                {

                    MessageBox.Show(e.Message);
                }
            }
        }
     
        private void SearchData()
        {
            try
            {
                SqlCommand command = new SqlCommand("Select * from tblborrow where borrowid like'%" + txtsearch.Text+"%'",SQLConnectiondb.cnn);
                SQLConnectiondb.cnn.Open();
                SqlDataAdapter adapter = new SqlDataAdapter(command);
                DataTable table = new DataTable();
                adapter.Fill(table);
                gunaDataGridView1.DataSource = table;
                SQLConnectiondb.cnn.Close();
            }
            catch (Exception e)
            {

                MessageBox.Show(e.Message);
            }
        }
        private void button3_Click(object sender, EventArgs e)
        {
            Clear();
        }

        private void gunaDataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if(gunaDataGridView1.Rows[e.RowIndex].Cells[e.ColumnIndex].Value != null)
            {
                  gunaDataGridView1.CurrentCell.Selected = true ;
                txtborrowid.Text = gunaDataGridView1.Rows[e.RowIndex].Cells[0].Value.ToString();
                cbostudentid.SelectedItem = gunaDataGridView1.Rows[e.RowIndex].Cells[1].Value.ToString();
                cbolibrarianid.SelectedItem = gunaDataGridView1.Rows[e.RowIndex].Cells[2].Value.ToString();
                cbobookid.SelectedItem = gunaDataGridView1.Rows[e.RowIndex].Cells[3].Value.ToString();      
                txtdateborrow.Value = Convert.ToDateTime(gunaDataGridView1.Rows[e.RowIndex].Cells["borrowdate"].Value);
                txtdatereturn.Value = Convert.ToDateTime(gunaDataGridView1.Rows[e.RowIndex].Cells["returndate"].Value);

            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            InsertRecord();
            GetData();     
            Clear();
        }

        private void button2_Click(object sender, EventArgs e)
        {

        }

        private void button4_Click(object sender, EventArgs e)
        {
            DeleteRecord();
            GetData();
            Clear();
        }

        private void button5_Click(object sender, EventArgs e)
        {
           
        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {
            SearchData();
        }

        private void gunaDataGridView1_DataError(object sender, DataGridViewDataErrorEventArgs e)
        {
            if (e.Exception.Message == "DataGridView Validating")
            {
                object value = gunaDataGridView1.Rows[e.RowIndex].Cells[e.ColumnIndex].Value;
                if (!((DataGridViewComboBoxColumn)gunaDataGridView1.Columns[e.ColumnIndex]).Items.Contains(value))
                {
                    ((DataGridViewComboBoxColumn)gunaDataGridView1.Columns[e.ColumnIndex]).Items.Add(value);
                    e.ThrowException = false;
                }
            }
        }
    }
}
