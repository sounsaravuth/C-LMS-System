﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using LMS_System.Database;

namespace LMS_System.Admin
{
    public partial class frmauthor : Form
    {
        String sex;
        public frmauthor()
        {
            InitializeComponent();
        }

        private void radioButton1_CheckedChanged(object sender, EventArgs e)
        {
            sex = "Male";
        }

        private void radioButton2_CheckedChanged(object sender, EventArgs e)
        {
            sex = "Female";
        }

        private void frmauthor_Load(object sender, EventArgs e)
        {
            SQLConnectiondb connectiondb = new SQLConnectiondb();
            connectiondb.DatabaseConnection();
            GetData();
        }
        private void GetData()
        {
            try
            {
                SqlCommand command = new SqlCommand("Select * from tblauthor", SQLConnectiondb.cnn);
                SQLConnectiondb.cnn.Open();
                SqlDataReader reader = command.ExecuteReader();
                bindingSource1.DataSource = reader;
                gunaDataGridView1.DataSource = bindingSource1;
            }
            catch (Exception e)
            {

                MessageBox.Show(e.Message);
            }
            finally
            {
                SQLConnectiondb.cnn.Close();
            }
        }
        private void InsertData()
        {
            //Validate Check Record Empty
            if (string.IsNullOrEmpty(txtauthorid.Text))
            {
                MessageBox.Show("Please Complate Information !" , "Complate Information" , MessageBoxButtons.OK , MessageBoxIcon.Warning);
                txtauthorid.Focus();
                return;
            }
            else
            {
                SqlCommand command = new SqlCommand("Select * from tblauthor where authorid='"+txtauthorid.Text+"'", SQLConnectiondb.cnn);
                SqlDataAdapter adapter = new SqlDataAdapter(command);
                DataSet dataSet = new DataSet();
                adapter.Fill(dataSet);
                int i = dataSet.Tables[0].Rows.Count;
                if(i > 0)
                {
                    MessageBox.Show("This Record Extist" , "Record Extist" , MessageBoxButtons.OK , MessageBoxIcon.Warning);
                    dataSet.Clear();
                    return;
                }
            }
            try
            {
                SqlCommand command = new SqlCommand("Insert into tblauthor (authorid,authorname,gender,dob,pob,address,tel,email)" +
                    " values (@authorid,@authorname,@gender,@dob,@pob,@address,@tel,@email)", SQLConnectiondb.cnn);
                SQLConnectiondb.cnn.Open();
                command.Parameters.AddWithValue("@authorid",txtauthorid.Text);
                command.Parameters.AddWithValue("@authorname",txtauthorname.Text);
                command.Parameters.AddWithValue("@gender",sex);
                command.Parameters.AddWithValue("@dob",txtdate.Text);
                command.Parameters.AddWithValue("@pob",txtpob.Text);
                command.Parameters.AddWithValue("@address",txtaddress.Text);
                command.Parameters.AddWithValue("@tel",txttel.Text);
                command.Parameters.AddWithValue("@email",txtemail.Text);
                command.ExecuteNonQuery();
                MessageBox.Show("Author Add New Successfully", "Author Add", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch (Exception e)
            {

                MessageBox.Show(e.Message);
            }
            finally
            {
                SQLConnectiondb.cnn.Close();
            }
        }
        //Update Record
        private void UpdateRecord()
        {
            if (MessageBox.Show("Do You Want To Update Author", "Question", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
            {
                try
                {
                    SqlCommand command = new SqlCommand("Update tblauthor set authorname=@authorname , gender=@gender , dob=@dob , pob=@pob , address=@address , tel=@tel , email=@email where authorid=@authorid ", SQLConnectiondb.cnn);
                    SQLConnectiondb.cnn.Open();
                    command.Parameters.AddWithValue("@authorid", txtauthorid.Text);
                    command.Parameters.AddWithValue("@authorname", txtauthorname.Text);
                    command.Parameters.AddWithValue("@gender", sex);
                    command.Parameters.AddWithValue("@dob", txtdate.Text);
                    command.Parameters.AddWithValue("@pob", txtpob.Text);
                    command.Parameters.AddWithValue("@address", txtaddress.Text);
                    command.Parameters.AddWithValue("@tel", txttel.Text);
                    command.Parameters.AddWithValue("@email", txtemail.Text);
                    command.ExecuteNonQuery();
                    MessageBox.Show("Author Update Successfully", "Author Update", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
                catch (Exception e)
                {
                    MessageBox.Show(e.Message);
                   
                }
                finally
                {
                    SQLConnectiondb.cnn.Close();
                }
            }
        }
        //Delete Record
        private void DeleteRecord()
        {
            if(MessageBox.Show("Do You Want To Delete Author" , "Question" , MessageBoxButtons.YesNo , MessageBoxIcon.Question) == DialogResult.Yes)
            {
                try
                {
                    SqlCommand command = new SqlCommand("Delete From tblauthor where authorid = @authorid", SQLConnectiondb.cnn);
                    SQLConnectiondb.cnn.Open();
                    command.Parameters.AddWithValue("@authorid",txtauthorid.Text);
                    command.ExecuteNonQuery();
                    SQLConnectiondb.cnn.Close();
                    MessageBox.Show("Author Delete Successfully", "Author Delete", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
                catch (Exception e)
                {

                    MessageBox.Show(e.Message);
                }
            }
        }
        
        private void ClearData()
        {
            txtauthorid.Clear();
            txtauthorname.Clear();
            txtemail.Clear();
            txtpob.Clear();
            txttel.Clear();
            txtaddress.Clear();
        }
        private void button1_Click(object sender, EventArgs e)
        {
            InsertData();
            GetData();
            ClearData();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            UpdateRecord();
            GetData();
            ClearData();
        }

        private void gunaDataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (gunaDataGridView1.Rows[e.RowIndex].Cells[e.ColumnIndex].Value != null)
            {
                gunaDataGridView1.CurrentCell.Selected = true;
                txtauthorid.Text = gunaDataGridView1.Rows[e.RowIndex].Cells[0].Value.ToString();
                txtauthorname.Text = gunaDataGridView1.Rows[e.RowIndex].Cells[1].Value.ToString();
                if (gunaDataGridView1.SelectedRows[0].Cells[2].Value.Equals("Female"))
                    radioButton2.Checked = true;
                else
                    radioButton2.Checked = true;

                if (gunaDataGridView1.SelectedRows[0].Cells[3].Value.Equals("Male"))
                    radioButton1.Checked = true;
                else
                    radioButton1.Checked = true;
                txtdate.Value = Convert.ToDateTime(gunaDataGridView1.Rows[e.RowIndex].Cells["dob"].Value);
                txtpob.Text = gunaDataGridView1.Rows[e.RowIndex].Cells[4].Value.ToString();
                txtaddress.Text = gunaDataGridView1.Rows[e.RowIndex].Cells[5].Value.ToString();
                txttel.Text = gunaDataGridView1.Rows[e.RowIndex].Cells[6].Value.ToString();
                txtemail.Text = gunaDataGridView1.Rows[e.RowIndex].Cells[7].Value.ToString();
            }
        }

        private void txtauthorname_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.Handled = !(char.IsLetter(e.KeyChar) || e.KeyChar == (char)Keys.Back || e.KeyChar == (char)Keys.Space || e.KeyChar == (char)Keys.Enter))
            {
                e.Handled = true;
                base.OnKeyPress(e);
                MessageBox.Show("allow Only Letter ", "Allow Only Letter", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }

        private void txtpob_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.Handled = !(char.IsLetter(e.KeyChar) || e.KeyChar == (char)Keys.Back || e.KeyChar == (char)Keys.Space || e.KeyChar == (char)Keys.Enter))
            {
                e.Handled = true;
                base.OnKeyPress(e);
                MessageBox.Show("allow Only Letter ", "Allow Only Letter", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }

        private void txtaddress_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.Handled = !(char.IsLetter(e.KeyChar) || e.KeyChar == (char)Keys.Back || e.KeyChar == (char)Keys.Space || e.KeyChar == (char)Keys.Enter))
            {
                e.Handled = true;
                base.OnKeyPress(e);
                MessageBox.Show("allow Only Letter ", "Allow Only Letter", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }

        private void txttel_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.Handled = !char.IsDigit(e.KeyChar) && !char.IsControl(e.KeyChar))
            {
                e.Handled = true;
                base.OnKeyPress(e);
                MessageBox.Show("Allow Only number", "Only Number", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }

        private void gunaDataGridView1_DataError(object sender, DataGridViewDataErrorEventArgs e)
        {
            if (e.Exception.Message == "DataGridView Validating")
            {
                object value = gunaDataGridView1.Rows[e.RowIndex].Cells[e.ColumnIndex].Value;
                if (!((DataGridViewComboBoxColumn)gunaDataGridView1.Columns[e.ColumnIndex]).Items.Contains(value))
                {
                    ((DataGridViewComboBoxColumn)gunaDataGridView1.Columns[e.ColumnIndex]).Items.Add(value);
                    e.ThrowException = false;
                }
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            DeleteRecord();
            GetData();
            ClearData();
        }
    }
}
