﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using LMS_System.Admin;
using LMS_System.Database;


namespace LMS_System.Admin
{
    public partial class frmstudent : Form
    {
        String sex;
        public frmstudent()
        {
            InitializeComponent();
        }

        private void frmstudent_Load(object sender, EventArgs e)
        {
            SQLConnectiondb connectiondb = new SQLConnectiondb();
            connectiondb.DatabaseConnection();
            Getdata();
        }
        //update Record
        private void UpdateData()
        {
            if(MessageBox.Show("Do You Want To Update Student ?","Update Student",MessageBoxButtons.YesNo,MessageBoxIcon.Question) == DialogResult.Yes)
            {
                try
                {
                    SqlCommand command = new SqlCommand("Update tblstudent set studentname=@studentname , gender=@gender , dob=@dob , pob=@pob , address=@address , tel=@tel , email=@email where studentid=@studentid ", SQLConnectiondb.cnn);
                    SQLConnectiondb.cnn.Open();
                    command.Parameters.AddWithValue("@studentid", txtstuid.Text);
                    command.Parameters.AddWithValue("@studentname", txtstuname.Text);
                    command.Parameters.AddWithValue("@gender", sex);
                    command.Parameters.AddWithValue("@dob", txtdate.Text);
                    command.Parameters.AddWithValue("@pob", txtpob.Text);
                    command.Parameters.AddWithValue("@address", txtaddress.Text);
                    command.Parameters.AddWithValue("@tel", txttel.Text);
                    command.Parameters.AddWithValue("@email", txtemail.Text);
                    command.ExecuteNonQuery();
                    MessageBox.Show("Student Update Successfully !", "Update Student", MessageBoxButtons.OK, MessageBoxIcon.Information);

                }
                catch (Exception e)
                {

                    MessageBox.Show("Student Can't Update Successfully", e.Message, MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                finally
                {
                    SQLConnectiondb.cnn.Close();
                }
            }
        }
        //Insert Record
        private void Insert()
        {
            //validate Empty Texbox Record
            if(string.IsNullOrEmpty(txtstuid.Text) && string.IsNullOrEmpty(txtstuname.Text) && string.IsNullOrEmpty(sex) && string.IsNullOrEmpty(txtdate.Text) && string.IsNullOrEmpty(txtpob.Text))
            {
                MessageBox.Show("Please Complate Information" , "Warning" , MessageBoxButtons.OK,MessageBoxIcon.Warning);
                txtstuid.Focus();
                return;
            }
            else

            {
                //validate Check Record Exists
                SqlCommand command = new SqlCommand("Select * from tblstudent where studentid='"+txtstuid.Text+"'", SQLConnectiondb.cnn);
                SqlDataAdapter adapter = new SqlDataAdapter(command);
                DataSet dataSet = new DataSet();
                adapter.Fill(dataSet);
                int i = dataSet.Tables[0].Rows.Count;
                if (i > 0)
                {
                    MessageBox.Show(" This Record Exists", "Exists Record" , MessageBoxButtons.OK,MessageBoxIcon.Warning);
                    dataSet.Clear();
                    return;
                }
              

            }

            try
            {
                SqlCommand command = new SqlCommand("INSERT INTO tblstudent (studentid,studentname,gender,dob,pob,address,tel,email) " +
                    "values(@studentid,@studentname,@gender,@dob,@pob,@address,@tel,@email)", SQLConnectiondb.cnn);
                SQLConnectiondb.cnn.Open();
                command.Parameters.AddWithValue("@studentid",txtstuid.Text);
                command.Parameters.AddWithValue("@studentname", txtstuname.Text);
                command.Parameters.AddWithValue("@gender" , sex);
                command.Parameters.AddWithValue("@dob", txtdate.Text);
                command.Parameters.AddWithValue("@pob", txtpob.Text);
                command.Parameters.AddWithValue("@address", txtaddress.Text);
                command.Parameters.AddWithValue("@tel", txttel.Text);
                command.Parameters.AddWithValue("@email", txtemail.Text);
                command.ExecuteNonQuery();
                MessageBox.Show("Student Add New Successfully !", "Add Student", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    
            }
            catch (Exception e)
            {

                MessageBox.Show("Student Can't Add Successfully", e.Message, MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                SQLConnectiondb.cnn.Close();
            }
        }
        // Delete Record
        private void Delete()
        {
            if(MessageBox.Show("Do You Want To Delete Student ?" , "Question" , MessageBoxButtons.YesNo , MessageBoxIcon.Question) == DialogResult.Yes)
            {
                try
                {
                    SqlCommand command = new SqlCommand("Delete From tblstudent where studentid=@student ? ", SQLConnectiondb.cnn);
                    SQLConnectiondb.cnn.Open();
                    command.Parameters.AddWithValue("@studentid", txtstuid.Text);
                    command.ExecuteNonQuery();
                    MessageBox.Show("Student Delete Successfully !", "Delete Student", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
                catch (Exception e)
                {

                    MessageBox.Show(e.Message);
                }
                finally
                {
                    SQLConnectiondb.cnn.Close();
                }
            }
        }
        //Clear Record
        private void Clear()
        {
            txtstuid.Clear();
            txtstuname.Clear();
            txtpob.Clear();
            gunaRadioButton2.Checked = false;
            gunaRadioButton1.Checked = false;
            txtaddress.Clear();
            txttel.Clear();
            txtemail.Clear();
        }
        //Fetch Record
        private void Getdata()
        {
            try
            {
                SqlCommand command = new SqlCommand("Select * from tblstudent", SQLConnectiondb.cnn);
           
                    SQLConnectiondb.cnn.Open();
              
                SqlDataReader reader = command.ExecuteReader();
                bindingSource1.DataSource = reader;
                gunaDataGridView1.DataSource = bindingSource1;
            }
            catch (Exception e)
            {

                MessageBox.Show(e.Message);
            }
            finally
            {
                SQLConnectiondb.cnn.Close();
            }
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            Search();
        }
        //Search Record By Name
        private void Search()
        {
            try
            {
                SqlCommand command = new SqlCommand("select * from tblstudent where studentname like '%"+txtsearch.Text+"%'", SQLConnectiondb.cnn);
                SQLConnectiondb.cnn.Open();
                SqlDataReader reader = command.ExecuteReader();
                bindingSource1.DataSource = reader;
                gunaDataGridView1.DataSource = bindingSource1;

            }
            catch (Exception e)
            {

                MessageBox.Show(e.Message);
            }
            finally
            {
                SQLConnectiondb.cnn.Close();
            }
        }
        //validate DataGirdView
        private void gunaDataGridView1_DataError(object sender, DataGridViewDataErrorEventArgs e)
        {
            if (e.Exception.Message == "DataGridView Validating")
            {
                object value = gunaDataGridView1.Rows[e.RowIndex].Cells[e.ColumnIndex].Value;
                if (!((DataGridViewComboBoxColumn)gunaDataGridView1.Columns[e.ColumnIndex]).Items.Contains(value))
                {
                    ((DataGridViewComboBoxColumn)gunaDataGridView1.Columns[e.ColumnIndex]).Items.Add(value);
                    e.ThrowException = false;
                }
            }
        }
        //Click Record To Update
        private void gunaDataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (gunaDataGridView1.Rows[e.RowIndex].Cells[e.ColumnIndex].Value != null)
            {
              Convert .ToInt32(  gunaDataGridView1.CurrentCell.Selected = true);
                txtstuid.Text = gunaDataGridView1.Rows[e.RowIndex].Cells[0].Value.ToString();
                txtstuname.Text = gunaDataGridView1.Rows[e.RowIndex].Cells[1].Value.ToString();
               
                if (gunaDataGridView1.SelectedRows[0].Cells[2].Value.Equals("Female"))
                    gunaRadioButton2.Checked = true;
                else
                    gunaRadioButton2.Checked = true;

                if (gunaDataGridView1.SelectedRows[0].Cells[3].Value.Equals("Male"))
                    gunaRadioButton1.Checked = true;
                else
                    gunaRadioButton1.Checked = true;
                txtdate.Value =  Convert.ToDateTime(  gunaDataGridView1.Rows[e.RowIndex].Cells["dob"].Value);
                txtpob.Text = gunaDataGridView1.Rows[e.RowIndex].Cells[4].Value.ToString();
                txtaddress.Text = gunaDataGridView1.Rows[e.RowIndex].Cells[5].Value.ToString();
                txttel.Text = gunaDataGridView1.Rows[e.RowIndex].Cells[6].Value.ToString();
                txtemail.Text= gunaDataGridView1.Rows[e.RowIndex].Cells[7].Value.ToString();
            }
        }

        private void gunaRadioButton1_CheckedChanged(object sender, EventArgs e)
        {
            sex = "Male";
        }

        private void gunaRadioButton2_CheckedChanged(object sender, EventArgs e)
        {
            sex = "Female";
        }

        private void button4_Click(object sender, EventArgs e)
        {
            Clear();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Insert();
            Getdata();
            Clear();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            Delete();
            Getdata();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            UpdateData();
            Getdata();
            Clear();
        }

        private void txtstuname_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.Handled = !(char.IsLetter(e.KeyChar) || e.KeyChar == (char)Keys.Back || e.KeyChar == (char)Keys.Space || e.KeyChar == (char)Keys.Enter))
            {
                e.Handled = true;
                base.OnKeyPress(e);
                MessageBox.Show("allow Only Name ", "Allow Only Letter", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }

          
        }

        private void txtaddress_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.Handled = !(char.IsLetter(e.KeyChar) || e.KeyChar == (char)Keys.Back || e.KeyChar == (char)Keys.Space || e.KeyChar == (char)Keys.Enter))
            {
                e.Handled = true;
                base.OnKeyPress(e);
                MessageBox.Show("allow Only Letter ", "Allow Only Letter", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }

        private void txtpob_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.Handled = !(char.IsLetter(e.KeyChar) || e.KeyChar == (char)Keys.Back || e.KeyChar == (char)Keys.Space || e.KeyChar == (char)Keys.Enter))
            {
                e.Handled = true;
                base.OnKeyPress(e);
                MessageBox.Show("allow Only Letter ", "Allow Only Letter", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }

        private void txttel_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.Handled = !char.IsDigit(e.KeyChar) && !char.IsControl(e.KeyChar))
            {
                e.Handled = true;
                base.OnKeyPress(e);
                MessageBox.Show("Allow Only number", "Only Number", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }

        private void txtstuid_KeyPress(object sender, KeyPressEventArgs e)
        {
            if(e.KeyChar == 13)
            {
                txtstuname.Focus();
            }
        }

        private void txtstuname_KeyDown(object sender, KeyEventArgs e)
        {
            if(e.KeyCode == Keys.Enter)
            {
                txtpob.Focus();
            }
        }

        private void txtpob_KeyDown(object sender, KeyEventArgs e)
        {
            if(e.KeyCode == Keys.Enter)
            {
                txtaddress.Focus();
            }
        }

        private void txtaddress_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                txttel.Focus();
            }
        }

        private void txttel_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                txtemail.Focus();
            }
        }
    }
}
