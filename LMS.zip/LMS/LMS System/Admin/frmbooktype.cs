﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using LMS_System.Database;

namespace LMS_System.Admin
{
    public partial class frmbooktype : Form
    {
        public frmbooktype()
        {
            InitializeComponent();
        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void frmbooktype_Load(object sender, EventArgs e)
        {
            SQLConnectiondb connectiondb = new SQLConnectiondb();
            connectiondb.DatabaseConnection();
            GetData();
        }
        private void GetData()
        {
            try
            {
                SqlCommand command = new SqlCommand("select * from tblbooktype", SQLConnectiondb.cnn);
                SQLConnectiondb.cnn.Open();
                SqlDataAdapter adapter = new SqlDataAdapter(command);
                DataTable table = new DataTable();
                adapter.Fill(table);
                gunaDataGridView1.DataSource = table;
            }
            catch (Exception e)
            {

                MessageBox.Show(e.Message);
            }
            finally
            {
                SQLConnectiondb.cnn.Close();
            }
        }
        private void InsertData()
        {
            if(string.IsNullOrEmpty(txtbookidtype.Text) && string.IsNullOrEmpty(txtbookname.Text))
            {
                MessageBox.Show("Please Complate Information Book !", "Complate Information" , MessageBoxButtons.OK,MessageBoxIcon.Warning);
                txtbookidtype.Focus();
                return;
            }
            else
            {
                SqlCommand command = new SqlCommand("Select * from tblbooktype where bookidtype='"+txtbookidtype.Text+"'" , SQLConnectiondb.cnn);
                SqlDataAdapter adapter = new SqlDataAdapter(command);
                DataSet dataSet = new DataSet();
                adapter.Fill(dataSet);
                int i = dataSet.Tables[0].Rows.Count;
                if(i> 0)
                {
                    MessageBox.Show("This Record Extist !", "Record Extist", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    dataSet.Clear();
                    return;
                }
            }
            try
            {
                SqlCommand command = new SqlCommand("Insert into tblbooktype (bookidtype,booktypename,description) " +
                    "values(@bookidtype,@booktypename,@description)", SQLConnectiondb.cnn);
                SQLConnectiondb.cnn.Open();
                command.Parameters.AddWithValue("@bookidtype", txtbookidtype.Text);
                command.Parameters.AddWithValue("@booktypename", txtbookname.Text);
                command.Parameters.AddWithValue("@description", txtdeatil.Text);
                command.ExecuteNonQuery();
                MessageBox.Show("Book Add New Successfully" , "Add New Book" , MessageBoxButtons.OK,MessageBoxIcon.Information);
            }
            catch (Exception e)
            {

                MessageBox.Show(e.Message);
            }
            finally
            {
                SQLConnectiondb.cnn.Close();
            }
        }
     private void UpdateData()
        {
            if (MessageBox.Show("Do You Want To Update Book ?", "Question", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
            {
                try
                {
                    SqlCommand command = new SqlCommand("Update tblbooktype set booktypename=@booktypename , description=@description where bookidtype=@bookidtype", SQLConnectiondb.cnn);
                    SQLConnectiondb.cnn.Open();
                    command.Parameters.AddWithValue("@bookidtype", txtbookidtype.Text);
                    command.Parameters.AddWithValue("@booktypename", txtbookname.Text);
                    command.Parameters.AddWithValue("@description", txtdeatil.Text);
                    command.ExecuteNonQuery();
                    MessageBox.Show("Book Update Successfully", "Update Book", MessageBoxButtons.OK, MessageBoxIcon.Information);

                }
                catch (Exception e)
                {

                    MessageBox.Show(e.Message);
                }
                finally
                {
                    SQLConnectiondb.cnn.Close();
                }
            }
        }
        private void ClearData()
        {
            txtbookidtype.Clear();
            txtbookname.Clear();
            txtdeatil.Clear();
        }
        private void button1_Click(object sender, EventArgs e)
        {
            InsertData();
            GetData();
            ClearData();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            ClearData();
        }
        private void DeleteData()
        {
            if (MessageBox.Show("Do You Want To Delete Book ?", "Question", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
            {
                try
                {
                    SqlCommand command = new SqlCommand("Delete from tblbooktype where bookidtype=@bookidtype", SQLConnectiondb.cnn);
                    SQLConnectiondb.cnn.Open();
                    command.Parameters.AddWithValue("@booktypeid", txtbookidtype.Text);
                    command.ExecuteNonQuery();
                    MessageBox.Show("Book Delete Successfully ", "Book Delete", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
                catch (Exception e)
                {

                    MessageBox.Show(e.Message);
                }
                finally
                {
                    SQLConnectiondb.cnn.Close();
                }
            }
        }
        private void SearchData()
        {
            try
            {
                SqlCommand command = new SqlCommand("Select * from tblbooktype where booktypename Like'%"+txtsearch.Text+"%'", SQLConnectiondb.cnn);
                SQLConnectiondb.cnn.Open();
                SqlDataAdapter adapter = new SqlDataAdapter(command);
                DataTable table = new DataTable();
                adapter.Fill(table);
                gunaDataGridView1.DataSource = table;
            }
            catch (Exception e)
            {

                MessageBox.Show(e.Message);
            }
            finally
            {
                SQLConnectiondb.cnn.Close();
            }
        }
        private void button4_Click(object sender, EventArgs e)
        {
            DeleteData();
            GetData();
            ClearData();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            UpdateData();
            GetData();
            ClearData();
        }

        private void gunaDataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if(gunaDataGridView1.Rows[e.RowIndex].Cells[e.ColumnIndex].Value != null)
            {
                gunaDataGridView1.CurrentCell.Selected = true;
                txtbookidtype.Text = gunaDataGridView1.Rows[e.RowIndex].Cells[0].Value.ToString();
                txtbookname.Text = gunaDataGridView1.Rows[e.RowIndex].Cells[1].Value.ToString();
                txtdeatil.Text = gunaDataGridView1.Rows[e.RowIndex].Cells[2].Value.ToString();
            }
        }

        private void txtsearch_TextChanged(object sender, EventArgs e)
        {
            SearchData();
        }
    }
}
