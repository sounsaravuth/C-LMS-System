﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using LMS_System.Database;

namespace LMS_System.Admin
{
    public partial class frmlibrairan : Form
    {
        String gender;
        public frmlibrairan()
        {
            InitializeComponent();
        }

        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {
            gender = "Male";
        }

        private void checkBox2_CheckedChanged(object sender, EventArgs e)
        {
            gender = "Female";
        }

        private void frmlibrairan_Load(object sender, EventArgs e)
        {
            SQLConnectiondb connectiondb = new SQLConnectiondb();
            connectiondb.DatabaseConnection();
            Getdata();
        }
        private void DeleteData()
        {
            if (MessageBox.Show("Do You Want To Delete Libraran ?", "Question", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
            {
                try
                {
                    SqlCommand command = new SqlCommand("Delete from tbllibrarian where librarianid=@librarianid", SQLConnectiondb.cnn);
                    SQLConnectiondb.cnn.Open();
                    command.Parameters.AddWithValue("@librarianid", txtlibraid.Text);
                    command.ExecuteNonQuery();
                    MessageBox.Show("Libraran Delete Successfully", "Liranran Delete ", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
                catch (Exception e)
                {

                    MessageBox.Show(e.Message);
                }
                finally
                {
                    SQLConnectiondb.cnn.Close();
                }
            }
        }
        private void Getdata()
        {
            try
            {
                SqlCommand command = new SqlCommand("Select * from tbllibrarian", SQLConnectiondb.cnn);

                SQLConnectiondb.cnn.Open();

                SqlDataReader reader = command.ExecuteReader();
                bindingSource1.DataSource = reader;
                gunaDataGridView1.DataSource = bindingSource1;
            }
            catch (Exception e)
            {

                MessageBox.Show(e.Message);
            }
            finally
            {
                SQLConnectiondb.cnn.Close();
            }
        }
        private void InsertData()
        {
            if(string.IsNullOrEmpty(txtlibraid.Text) && string.IsNullOrEmpty(txtliname.Text))
            {
                MessageBox.Show("Please Complate Information ! ", "Complate Information", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                txtlibraid.Focus();
                return;
            }
            else
            {
                //validate Record Extist
                SqlCommand command = new SqlCommand("Select * from tbllibrarian where librarianid='"+txtlibraid.Text+"'", SQLConnectiondb.cnn);
                SqlDataAdapter adapter = new SqlDataAdapter(command);
                DataSet data = new DataSet();
                adapter.Fill(data);
                int i = data.Tables[0].Rows.Count;
                if(i  > 0)
                {
                    MessageBox.Show("This Record Extisti !", "Record Extist", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    data.Clear();
                    return;
                }
            }
            try
            {
                SqlCommand command = new SqlCommand("Insert into tbllibrarian (librarianid,librarianname,gender,dob,pob,address,tel,email)" +
                    " values (@librarianid,@librarianname,@gender,@dob,@pob,@address,@tel,@email)", SQLConnectiondb.cnn);
                SQLConnectiondb.cnn.Open();
                command.Parameters.AddWithValue("@librarianid",txtlibraid.Text);
                command.Parameters.AddWithValue("@librarianname",txtliname.Text);
                command.Parameters.AddWithValue("@gender",gender);
                command.Parameters.AddWithValue("@dob",txtdate.Text);
                command.Parameters.AddWithValue("@pob",txtpob.Text);
                command.Parameters.AddWithValue("@address",txtaddress.Text);
                command.Parameters.AddWithValue("@tel",txttel.Text);
                command.Parameters.AddWithValue("@email",txtemail.Text);
                command.ExecuteNonQuery();
                MessageBox.Show("Libraran Add New Successfully", "Liranran Add ", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch (Exception e)
            {

                MessageBox.Show(e.Message);
            }
            finally
            {
                SQLConnectiondb.cnn.Close();
            }
        }
        private void UpdateData()
        {
            if (MessageBox.Show("Do You Want To Update Libraran ?", "Question", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
            {
                try
                {
                    SqlCommand command = new SqlCommand("Update tbllibrarian set librarianname=@librarianname , gender=@gender , dob=@dob , pob=@pob , address=@address , tel=@tel , email=@email where librarianid=@librarianid", SQLConnectiondb.cnn);
                    SQLConnectiondb.cnn.Open();
                    command.Parameters.AddWithValue("@librarianid", txtlibraid.Text);
                    command.Parameters.AddWithValue("@librarianname", txtliname.Text);
                    command.Parameters.AddWithValue("@gender", gender);
                    command.Parameters.AddWithValue("@dob", txtdate.Text);
                    command.Parameters.AddWithValue("@pob", txtpob.Text);
                    command.Parameters.AddWithValue("@address", txtaddress.Text);
                    command.Parameters.AddWithValue("@tel", txttel.Text);
                    command.Parameters.AddWithValue("@email", txtemail.Text);
                    command.ExecuteNonQuery();
                    MessageBox.Show("Libraran Update Successfully", "Liranran Update ", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
                catch (Exception e)
                {

                    MessageBox.Show(e.Message);
                }
                finally
                {
                    SQLConnectiondb.cnn.Close();
                }
            }
        }
        private void ClearData()
        {
            txtlibraid.Clear();
            txtliname.Clear();
            txtpob.Clear();
            txtemail.Clear();
            txtaddress.Clear();
            txttel.Clear();
            checkBox1.Checked = false;
            checkBox2.Checked = false;

        }

        private void button1_Click(object sender, EventArgs e)
        {
            InsertData();
            Getdata();
            ClearData();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            ClearData();
        }
        private void Searchdata()
        {
            try
            {
                SqlCommand command = new SqlCommand("Select * from tbllibrarian where librarianname Like '%"+txtsearch.Text+"%'", SQLConnectiondb.cnn);

                SQLConnectiondb.cnn.Open();

                SqlDataReader reader = command.ExecuteReader();
                bindingSource1.DataSource = reader;
                gunaDataGridView1.DataSource = bindingSource1;
            }
            catch (Exception e)
            {

                MessageBox.Show(e.Message);
            }
            finally
            {
                SQLConnectiondb.cnn.Close();
            }
        }
        private void txtsearch_TextChanged(object sender, EventArgs e)
        {
            Searchdata();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            UpdateData();
            Getdata();
            ClearData();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            DeleteData();
            Getdata();
            ClearData();
        }

        private void gunaDataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (gunaDataGridView1.Rows[e.RowIndex].Cells[e.ColumnIndex].Value != null)
            {
                gunaDataGridView1.CurrentCell.Selected = true;
                txtlibraid.Text = gunaDataGridView1.Rows[e.RowIndex].Cells[0].Value.ToString();
                txtliname.Text = gunaDataGridView1.Rows[e.RowIndex].Cells[1].Value.ToString();
                if (gunaDataGridView1.SelectedRows[0].Cells[2].Value.Equals("Female"))
                    checkBox2.Checked = true;
                else
                    checkBox2.Checked = false;

                if (gunaDataGridView1.SelectedRows[0].Cells[3].Value.Equals("Male"))
                    checkBox1.Checked = true;
                else
                    checkBox1.Checked = false;
                txtdate.Value = Convert.ToDateTime(gunaDataGridView1.Rows[e.RowIndex].Cells["dob"].Value);
                txtpob.Text = gunaDataGridView1.Rows[e.RowIndex].Cells[4].Value.ToString();
                txtaddress.Text = gunaDataGridView1.Rows[e.RowIndex].Cells[5].Value.ToString();
                txttel.Text = gunaDataGridView1.Rows[e.RowIndex].Cells[6].Value.ToString();
                txtemail.Text = gunaDataGridView1.Rows[e.RowIndex].Cells[7].Value.ToString();
            }
        }

        private void txtliname_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.Handled = !(char.IsLetter(e.KeyChar) || e.KeyChar == (char)Keys.Back || e.KeyChar == (char)Keys.Space || e.KeyChar == (char)Keys.Enter))
            {
                e.Handled = true;
                base.OnKeyPress(e);
                MessageBox.Show("allow Only Letter ", "Allow Only Letter", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }

        private void txtpob_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.Handled = !(char.IsLetter(e.KeyChar) || e.KeyChar == (char)Keys.Back || e.KeyChar == (char)Keys.Space || e.KeyChar == (char)Keys.Enter))
            {
                e.Handled = true;
                base.OnKeyPress(e);
                MessageBox.Show("allow Only Letter ", "Allow Only Letter", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }

        private void txtaddress_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.Handled = !(char.IsLetter(e.KeyChar) || e.KeyChar == (char)Keys.Back || e.KeyChar == (char)Keys.Space || e.KeyChar == (char)Keys.Enter))
            {
                e.Handled = true;
                base.OnKeyPress(e);
                MessageBox.Show("allow Only Letter ", "Allow Only Letter", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }

        private void txttel_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.Handled = !char.IsDigit(e.KeyChar) && !char.IsControl(e.KeyChar))
            {
                e.Handled = true;
                base.OnKeyPress(e);
                MessageBox.Show("Allow Only number", "Only Number", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }

        private void gunaDataGridView1_DataError(object sender, DataGridViewDataErrorEventArgs e)
        {
            if (e.Exception.Message == "DataGridView Validating")
            {
                object value = gunaDataGridView1.Rows[e.RowIndex].Cells[e.ColumnIndex].Value;
                if (!((DataGridViewComboBoxColumn)gunaDataGridView1.Columns[e.ColumnIndex]).Items.Contains(value))
                {
                    ((DataGridViewComboBoxColumn)gunaDataGridView1.Columns[e.ColumnIndex]).Items.Add(value);
                    e.ThrowException = false;
                }
            }
        }
    }
}
